python -m learning_to_simulate.read_data --data_path ~/gnn_dna/datasets/cuboid --file_name test.tfrecord
