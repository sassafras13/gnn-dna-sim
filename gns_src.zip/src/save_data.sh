python -m learning_to_simulate.save_data --file_path ~/gnn_dna/datasets/cuboid/trajectory_sim.dat --train_split 0.8 --val_split 0.1 --num_particles 13608 
