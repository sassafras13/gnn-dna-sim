python -m learning_to_simulate.render_rollout --rollout_path=/home/emma/gnn_dna/rollouts/cuboid-c3/rollout_valid_0.pkl
