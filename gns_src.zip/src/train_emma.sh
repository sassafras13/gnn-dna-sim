python -m learning_to_simulate.train --data_path=/home/mmbl/Documents/ebenjami/gnn_dna/datasets/cuboid --model_path=/home/mmbl/Documents/ebenjami/gnn_dna/models/test --batch_size=1 --num_steps=5 
