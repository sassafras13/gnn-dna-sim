python -m learning_to_simulate.render_rollout --rollout_path=/home/emma/gnn_dna/rollouts/rollout_test_1.pkl --step_stride=1
