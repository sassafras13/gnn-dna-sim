# This script runs oxdna analysis on simulation data to extract length data as a function of sim time.
# The data is then exported to be analyzed in a Jupyter notebook.
# Many thanks to Erik Poppleton, Joakim Bohlin, Michael Matthies, Shuchi Sharma, Fei Zhang, Petr Sulc: Design, optimization, and analysis of large DNA and RNA nanostructures through interactive visualization, editing, and molecular simulation. (2020) Nucleic Acids Research e72. https://doi.org/10.1093/nar/gkaa417

# import libraries
import os
import csv
import argparse
import pandas as pd
import numpy as np
import altair as alt
import matplotlib.pyplot as plt

# function that calls oxdna analysis tool in command line
def runDistanceAnalysis(base_pairs, oxdna_dir, output_file, input_file, traj_file):

    # build command to run oxdna analysis tools
    # the format for calling distance.py is:
    # (-c -o <output> -f <histogram/trajectory/both> -d <data file output>)...
    # -i <<input> <trajectory> <particleID 1> <particleID 2> (<particleID 1> <particleID 2> ...)>
   
    command = 'python3 {0}/distance.py -o output -f trajectory -d {1}/output_data.txt -i {2} {3} {4}'.format(oxdna_dir, output_file, input_file, traj_file, base_pairs) 

    # call the distance.py function in oxdna analysis tools
    os.system(command)
    print("Distance analysis complete.")

def runRMSFAnalysis(oxdna_dir, deviation_file, traj_file):

    # build command to run oxdna analysis tools 
    # the format for calling compute_mean.py is: 
    # -p <n_cpus> -f <oxDNA/json/both> -o <mean structure> -d <deviations file> -i <index file> -a <align conf id>

    command = "python3 {0}/compute_mean.py -f json -d {1} {2}".format(oxdna_dir, deviation_file, traj_file)
    os.system(command)
    print("RMSF analysis complete.")

# function that builds string of base pairs to be studied
def buildBasePairStr(base_pair_file):

    # read the base pair CSV file
    with open(base_pair_file) as f:
        reader = csv.reader(f)
        
        # skip first row
        #next(reader)

        # create empty list 
        base_pairs_list = [] 

        for row in reader:

            # append each pair of bases to a string
            base_pairs_list.append(str(row[0]))
            base_pairs_list.append(str(row[1]))

        base_pairs = ' '.join(base_pairs_list)

    return base_pairs

def plotTrajectoryDataPLT(output_file):
    data = output_file + "/output_data.txt"
    data_array = np.loadtxt(data, skiprows=1)
    T = data_array.shape[0]-1

    plt.figure()
    for i in range(data_array.shape[1]):
        plt.plot(list(range(T)), data_array[1:,i], label="Pair {0}".format(i))
    plt.xlabel("Simulation Time")
    plt.ylabel("Distance Between Bases")
    plt.legend()
    # plt.show()
    plt.savefig("{}trajectories.png".format(output_file))

def plotTrajectoryDataAltair(output_file):
    traj_data_filename = output_file + "/output_data.txt"
    df_traj_data = pd.read_csv(traj_data_filename, delimiter='\t')
    col_names = list(df_traj_data)

    # add a column for sim time
    df_traj_data['sim time'] = range(0,len(df_traj_data))

    # length
    line1 = alt.Chart(df_traj_data).transform_fold(
        [col_names[0], col_names[1], col_names[2]]
        ).mark_line(color='blue').encode(
        x='sim time:Q',
        y = 'mean(value):Q',

    )

    band1 = alt.Chart(df_traj_data).transform_fold(
        [col_names[0], col_names[1], col_names[2]]
        ).mark_errorband(color='blue', extent='stdev').encode(
        x = 'sim time:Q',
        y = alt.Y('value:Q')
    )

    # width
    line2 = alt.Chart(df_traj_data).transform_fold(
        [col_names[0], col_names[1], col_names[2]]
        ).mark_line(color='green').encode(
        x='sim time:Q',
        y = 'mean(value):Q'
    )

    band2 = alt.Chart(df_traj_data).transform_fold(
        [col_names[0], col_names[1], col_names[2]]
        ).mark_errorband(color='green', extent='stdev').encode(
        x = 'sim time:Q',
        y = alt.Y('value:Q')
    )

    # height
    line3 = alt.Chart(df_traj_data).transform_fold(
        [col_names[0], col_names[1], col_names[2]]
        ).mark_line(color='red').encode(
        x='sim time:Q',
        y = 'mean(value):Q'
    )

    band3 = alt.Chart(df_traj_data).transform_fold(
        [col_names[0], col_names[1], col_names[2]]
        ).mark_errorband(color='red', extent='stdev').encode(
        x = 'sim time:Q',
        y = alt.Y('value:Q'),
    )


    fullChart = band1 + line1 + band2 + line2 + band3 + line3
    save_location = str(output_file + "base_pair_trajectories.html")
    print("save location", save_location)
    fullChart.save(save_location, embed_options={"renderer":"svg"})

# wrapper function 
def doAnalysis(base_pair_file, oxdna_dir, deviation_file, output_file, input_file, traj_file):

    # call buildBasePairList to get list of base pairs
    base_pairs = buildBasePairStr(base_pair_file)

    # call runOxdnaAnalysis with base_pairs to generate analysis file as a text file
    runDistanceAnalysis(base_pairs, oxdna_dir, output_file, input_file, traj_file)

    # plot the resulting data using Altair and save
    plotTrajectoryDataPLT(output_file)

    runRMSFAnalysis(oxdna_dir, deviation_file, traj_file)

# main
if __name__ == "__main__":

    # the arguments to be passed into this script are:
    # - the directory where the list of base pairs are
    # - the directory where the oxdna analysis tools are located
    # - the directory where the output data should be saved
    # - the path to the simulation input file
    # - the path to the simulation trajectory file
    parser = argparse.ArgumentParser()
    parser.add_argument("-b", '--base_pairs', help='Enter the path to the CSV file containing the list of base pairs to be studied.', type=str)
    parser.add_argument("-x", '--oxdna_dir', help='Enter the directory where the oxdna-analysis-tools repo is located.', type=str)
    parser.add_argument("-d", "--deviation_file", help="Enter the name to save the deviations file to.", type=str)
    parser.add_argument("-o", '--output_file', help='Enter the directory where the output data file should be stored.', type=str)
    parser.add_argument("-i", '--input_file', help='Enter the directory where the oxdna simulation input file is stored.', type=str)
    parser.add_argument("-t", '--traj_file', help='Enter the directory where the trajectory file generated during simulation is stored.', type=str)
    args = parser.parse_args()

    # call doAnalysis
    doAnalysis(args.base_pairs, args.oxdna_dir, args.deviation_file, args.output_file, args.input_file, args.traj_file)

    # test command
#    python3 runOxdna.py /home/emma/repos/dna-toy-model/data/00-base/01-sim/01-analysis/pairs.csv /home/emma/repos/oxdna_analysis_tools /home/emma/repos/dna-toy-model/data/00-base/01-sim/01-analysis /home/emma/repos/dna-toy-model/data/00-base/01-sim/00-raw/min-relax-simSHORT/input_sim /home/emma/repos/dna-toy-model/data/00-base/01-sim/00-raw/min-relax-simSHORT/sim_out/trajectory_sim.dat

