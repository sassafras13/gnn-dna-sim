DATASET=$1
STEPS=$2

python3 -m learning_to_simulate.train \
  --data_path=./learning_to_simulate/tmp/datasets/$DATASET \
  --model_path=./learning_to_simulate/tmp/models/$DATASET \
  --batch_size=1 \
  --num_steps=$STEPS
