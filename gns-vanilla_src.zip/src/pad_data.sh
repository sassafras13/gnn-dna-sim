
DATASET=$1
NUMFRAME=$2

NUMPART=$(head -n 1 ./learning_to_simulate/tmp/datasets/$DATASET/$DATASET.top | cut -d ' ' -f 1)

FSTART=$(grep 't = ' ./learning_to_simulate/tmp/datasets/$DATASET/$DATASET.dat | tail -1 | cut -d ' ' -f 3)
FINT=$(grep 't = ' ./learning_to_simulate/tmp/datasets/$DATASET/$DATASET.dat | tail -2 | cut -d ' ' -f 3 | awk 'NR > 1 { print $0 - prev } { prev = $0 }')

python3 -m learning_to_simulate.pad \
   --file_path ./learning_to_simulate/tmp/datasets/$DATASET/$DATASET.dat \
   --frame_start $FSTART --frame_step $FINT \
   --num_frames $NUMFRAME \
   --num_particles $NUMPART