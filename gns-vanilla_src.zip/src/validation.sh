DATASET=$1
SPLIT=$2
STEPS=$3

python3 -m learning_to_simulate.train \
  --data_path=./learning_to_simulate/tmp/datasets/$DATASET \
  --model_path=./learning_to_simulate/tmp/models/$DATASET \
  --batch_size=1 \
  --mode="eval" \
  --num_steps=$STEPS \
  --eval_split=$SPLIT