import argparse

def main():

    ############### ARGPARSE ###################
    parser = argparse.ArgumentParser(description="Argument Parser")
    parser.add_argument("--file_path", help="Path to file to pad with extra data.",
                        default="/tmp/datasets/Cuboid/trajectory_sim.dat")
    parser.add_argument("--num_frames", help="Percentage of frames to add to train file", default=400, type=int)
    parser.add_argument("--frame_start", help = "The time-step number of the first padded frame.", default=1, type=int)
    parser.add_argument("--frame_step", help = "The change in time-step between time frames. Same as dt.", default=1, type=int)
    parser.add_argument("--num_particles", help = "The number of particles in the system.", default = 1, type = int)
    args = parser.parse_args()

    # store command line arguments
    rawDataPath = args.file_path
    nPaddedFrames = args.num_frames
    nParticles = args.num_particles

    with open(rawDataPath, "a") as f:

        frameNum = args.frame_start + args.frame_step

        # create nPaddedFrames number of dummy frames
        for iFrame in range(nPaddedFrames):

            # write header and data
            f.write("t = " + str(frameNum) + "\n")
            f.write("b = 0 0 0\n")
            f.write("E = 0 0 0\n")
            for iParticle in range(nParticles): f.write("0.0 0.0 0.0 0.0 0.0 0.0 0.0 0.0 0.0 0.0 0.0 0.0 0.0 0.0 0.0\n")

            # increment frame number
            frameNum += args.frame_step

main()