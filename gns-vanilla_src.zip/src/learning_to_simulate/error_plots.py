# import data using pandas
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

font = {'family' : 'normal',
        'weight' : 'normal',
        'size'   : 18}

plt.rc('font', **font)

dirname = "./learning_to_simulate/tmp/models/Hexagon2DRelax/"
trainfilename = "train_loss.csv"
df1 = pd.read_csv(dirname+trainfilename)
print(df1.head())
df1 = df1.rename(columns={"loss":"Train Loss"})

valfilename = "val_loss.csv"
df = pd.read_csv(dirname+valfilename)
df = df.rename(columns={"loss":"Validation Loss"})
print(df.head())

val_loss = df["Validation Loss"]
df1 = df1.join(val_loss)
print(df1.head())

ostfilename = "onestep_loss.csv"
df2 = pd.read_csv(dirname + ostfilename)

ost_loss = df2["One-Step Loss"]
df1 = df1.join(ost_loss)

# plot curves
df1.plot(x="Step", y=["Train Loss", "Validation Loss"], linewidth=8)
plt.xlabel("Epoch")
plt.ylabel("Loss")
plt.title("Single DNA Strand (GNS), r = 0.85nm")
plt.savefig("dna_loss.png", bbox_inches='tight')
plt.show()