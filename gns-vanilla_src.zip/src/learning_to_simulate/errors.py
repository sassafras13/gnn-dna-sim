import numpy as np
import pickle
import pandas as pd
import argparse

def est_acceleration(V, dt):

    accV = []
    for frame in range(1, len(V) - 1):
        left = V[frame - 1]
        center = V[frame]
        right = V[frame + 1]

        approx = (left + (-2 * center) + right) / (dt**2)
        accV.append(approx)

    return np.stack(accV)

def mae(Y, Ypred):
    return np.mean(np.absolute(Y - Ypred), axis = 1)

def mse(Y, Ypred):
    return np.mean((Y - Ypred)**2, axis = 1)

def main():

    parser = argparse.ArgumentParser(description="hi")
    parser.add_argument("--file_path", help="Path to rollout trajectory to calculate error.")
    args = parser.parse_args()

    print(args.file_path)

    with open(args.file_path, "rb") as file:
        data = pickle.load(file)

    predicted = data["predicted_rollout"]#[:5, 0, :]
    truth = data["ground_truth_rollout"]#[:5, 0, :]

    p_acc = est_acceleration(predicted, 5)
    t_acc = est_acceleration(truth, 5)

    aberr = mae(p_acc, t_acc)
    mserr = mse(p_acc, t_acc)

    print(np.mean(aberr))
    print(np.mean(mserr))

    #print(est_acceleration(truth, 0.005))

    #print(truth)


main()