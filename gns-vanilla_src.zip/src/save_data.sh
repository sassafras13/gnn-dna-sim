
DATASET=$1
NUMPART=$(head -n 1 ./learning_to_simulate/tmp/datasets/$DATASET/$DATASET.top | cut -d ' ' -f 1)

python3 -m learning_to_simulate.save_data \
   --file_path ./learning_to_simulate/tmp/datasets/$DATASET/$DATASET.dat \
   --train_split 0.833 --val_split 0.0 \
   --num_particles $NUMPART

mv *.tfrecord ./learning_to_simulate/tmp/datasets/$DATASET/