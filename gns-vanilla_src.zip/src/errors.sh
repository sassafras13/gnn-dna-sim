DATASET=$1
SPLIT=$2

F="rollout_${SPLIT}_0.pkl"

python3 -m learning_to_simulate.errors \
  --file_path ./learning_to_simulate/tmp/rollouts/$DATASET/$F