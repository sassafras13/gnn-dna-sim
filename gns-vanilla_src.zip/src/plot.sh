DATASET=$1

python3 -m learning_to_simulate.render_rollout \
    --rollout_path=./learning_to_simulate/tmp/rollouts/$DATASET/rollout_train_0.pkl