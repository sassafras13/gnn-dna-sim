DATASET=$1
SPLIT=$2

python3 -m learning_to_simulate.train \
    --mode="eval_rollout" \
    --eval_split=$SPLIT \
    --data_path=./learning_to_simulate/tmp/datasets/$DATASET \
    --model_path=./learning_to_simulate/tmp/models/$DATASET \
    --output_path=./learning_to_simulate/tmp/rollouts/$DATASET