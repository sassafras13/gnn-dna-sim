
DATASET=$1
NUMFRAME=$(grep -c 't =' ./learning_to_simulate/tmp/datasets/$DATASET/$DATASET.dat)

python3 -m learning_to_simulate.tsplit_data\
   --file_path ./learning_to_simulate/tmp/datasets/$DATASET/$DATASET.dat \
   --train_split 0.5 --val_split 0.5 \
   --num_frames $NUMFRAME

mv *.tfrecord ./learning_to_simulate/tmp/datasets/$DATASET/