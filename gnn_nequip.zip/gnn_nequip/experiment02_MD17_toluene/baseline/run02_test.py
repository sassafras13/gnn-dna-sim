## make prediction
# parameters
from nequip_fun import nequip_fun
import numpy as np

fname_model = 'model_deployed.pth'
fname_config_test = 'config_test.yaml'
fname_pred = 'data_pred.npz'
fname_test = 'data_test.npz'
batch_size = 50
N_test = 500

# prepare test data
data = np.load(fname_test)
data_E = data['E']
data_F = data['F']
data_R = data['R']
data_z = data['z']
data_E = data_E[0:N_test]
data_F = data_F[0:N_test]
data_R = data_R[0:N_test]
placeholder = np.array('', dtype='|S1')
np.savez(fname_test, E=data_E, F=data_F, R=data_R, z=data_z, 
          name=placeholder, type=placeholder, theory=placeholder, md5=placeholder)

# run predict_batch
energy_list, forces_list = nequip_fun.predict_batch(fname_model, fname_config_test, batch_size=batch_size)

np.savez(fname_pred, E=energy_list, F=forces_list)
