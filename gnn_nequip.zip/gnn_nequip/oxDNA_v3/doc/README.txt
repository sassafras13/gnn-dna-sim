oxDNA README
-------------------------------------------------------------------------------

oxDNA is a simulation code that was initially conceived as an implementation of the coarse-grained DNA
model introduced by T. E. Ouldridge, J. P. K. Doye and A. A. Louis (http://dx.doi.org/10.1063/1.3552946).
These simulations use the VMMC algorithm to simulate the strand displacement reactions for different configurations.
The initial configurations are in the Initial_configuration folder, the repulsion planes and harmonic traps simulations are in the FORCES folder, while the actual strand displacement simulations are in the Strand_displacement folder.  
Inside the Strand_displacement folder there are two subfolder for each configuration corresponding to the first and the last 3 days of simulations.  

REQUIREMENTS
-------------------------------------------------------------------------------

Without CUDA support:
cmake >= 2.6
make
gcc >= 4.2 / icc >= 11.0

With CUDA support:
cmake >= 2.8
make
gcc >= 4.2 / icc >= 11.0
CUDA toolkit >= 4.0

Generating the documentation (with 'make docs', see below) requires doxygen. 

COMPILING oxDNA
-------------------------------------------------------------------------------

Extract the oxDNA archive and then:

cd oxDNA 		# enter the oxDNA folder
mkdir build 	# create a new build folder. It is good practice to compile out-of-source
cd build
cmake ..		# here you can specify additional options, see next section
make -j4		# compile oxDNA. The -jX make option makes it compile the code in parallel by using X threads.

At the end of the compilation three executables (oxDNA, DNAnalysis and confGenerator) will be placed
in the build/bin folder.

CMAKE OPTIONS
-------------------------------------------------------------------------------

-DCUDA=ON		Enables CUDA support
-DDebug=ON		Compiles with debug symbols and without optimisation flags
-DG=ON			Compiles with debug symbols + optimisation flags
-DINTEL=ON		Uses INTEL's compiler suite
-DMPI=ON		Compiles oxDNA with MPI support
-DCXX11=ON		Compiles oxDNA with c++11 support
-DSIGNAL=OFF	Handling system signals is not supported everything. Set this flag to OFF to remove this feature
-DMOSIX=ON		Makes oxDNA compatible with MOSIX

INPUT FILE OPTIONS
-------------------------------------------------------------------------------

As always in UNIX environments, everything is case sensitive.
The options are in the form key = value. Key-value pairs should be either on different
lines or separated by a semicolon. There can be arbitrary spaces before and after both key and value. 
Line with a leading # will be treated as comments. The expected type of the value is specified between < and >. 
A <bool> key can be specified with values 1|0, yes|no or true|false.  
The | symbol (pipe) is used to indicate the different values that can be used to specify a value for the key.
Keys between [ and ] are optional.

Core options:

    T = <float>
        temperature of the simulation. It can be expressed in simulation units
        or kelvin (append a k or K after the value) or celsius (append a c or
        C after the value).
    [fix_diffusion = <bool>]
        if true, particles that leave the simulation box are brought back in
        via periodic boundary conditions. Defaults to true.
    [seed = <int>]
        seed for the random number generator. On Unix systems, defaults to
        either a number from /dev/urandom or to time(NULL)
    [confs_to_skip = <int>]
        how many configurations should be skipped before using the next one as
        the initial configuration, defaults to 0
    restart_step_counter = <boolean>/<bool>
        false means that the step counter will start from the value read in
        the configuration file, true means that the step counter will start
        from 0/if True oxDNA will reset the step counter to 0, otherwise it
        will start from the step counter found in the initial configuration.
        Defaults to False.
    [external_forces = <bool>]
        specifies whether there are external forces acting on the nucleotides
        or not. If it is set to 1, then a file which specifies the external
        forces' configuration has to be provided (see external_forces_file)
    [external_forces_file = <path>]
        specifies the file containing all the external forces' configurations.
        Currently there are six supported force types: string, twist, trap,
        repulsion_plane, repulsion_plane_moving and mutual_trap (see
        EXAMPLES/TRAPS for some examples)
    [back_in_box = <bool>]
        whether particles should be brought back into the box when a
        configuration is printed or not, defaults to false
    [lastconf_file = <path>]
        path to the file where the last configuration will be dumped
    trajectory_file = <path>
        path to the file which will contain the output trajectory of the
        simulation
    [binary_initial_conf = <bool>]
        whether the initial configuration is a binary configuration or not,
        defaults to false
    [lastconf_file_bin = <path>]
        path to the file where the last configuration will be printed in
        binary format, if not specified no binary configurations will be
        printed
    [print_reduced_conf_every = <int>]
        every how many time steps configurations containing only the centres
        of mass of the strands should be printed. If 0, no reduced
        configurations will be printed
    [reduced_conf_output_dir = <path>]
        path to the folder where reduced configurations will be printed
    [no_stdout_energy = <bool>]
        if true oxDNA will not print the default simulation output, including
        the energy, to stdout. Defaults to false
    [print_timings = <bool>]
        whether oxDNA should print out to a file performance timings at the
        end of the simulation or not, defaults to false
    [timings_filename = <path>]
        path to the file where timings will be printed
    [output_prefix = <string>]
        the name of all output files will be preceded by this prefix, defaults
        to an empty string
    [checkpoint_every = <int>]
        If > 0, it enables the production of checkpoints, which have a binary
        format. Beware that trajectories that do have this option enabled will
        differ from trajectories that do not. If this key is specified, at
        least one of checkpoint_file and checkpoint_trajectory needs to be
        specified
    [checkpoint_file = <string>]
        File name for the last checkpoint. If not specified, the last
        checkpoint will not be printed separately
    [checkpoint_trajectory = <string>]
        File name for the checkpoint trajectory. If not specified, only the
        last checkpoint will be printed
    [reload_from = <string>]
        checkpoint to reload from. This option is incompatible with the keys
        conf_file and seed, and requires restart_step_counter=0 as well as
        binary_initial_conf!=1
    [print_input = <bool>]
        make oxDNA write the input key=value pairs used by the simulation in a
        file named input.pid, with pid being the oxDNA pid. Defaults to False.
    conf_file = <string>
        path to the starting configuration
    steps = <int>
        length of the simulation, in time steps
    [equilibration_steps = <int>]
        number of equilibration steps. During equilibration, oxDNA does not
        generate any output. Defaults to 0
    time_scale = linear/log_lin
        a linear time_scale will make oxDNA print linearly-spaced
        configurations. a log_lin will make it print linearly-spaced cycles of
        logarithmically-spaced configurations.
    print_conf_interval = <int>
        if the time scale is linear, this is the number of time steps between
        the outputing of configurations, otherwise this is just the first
        point of the logarithmic part of the log_lin time scale
    print_conf_ppc = <int>
        mandatory only if time_scale == log_line. This is the number of
        printed configurations in a single logarithmic cycle.
    [print_energy_every = <int>]
        number of time steps between the outputing of the energy (and of the
        other default observables such as acceptance ratios in Monte Carlo
        simulations). Defaults to 0.
    verlet_skin = <float>
        width of the skin that controls the maximum displacement after which
        Verlet lists need to be updated.
    [list_type = verlet|cells|no]
        Type of neighbouring list to be used in CPU simulations. 'no' implies
        a O(N^2) computational complexity. Defaults to verlet.
    [use_average_seq = <boolean>]
        defaults to yes
    [seq_dep_file = <string>]
        sets the location of the files with sequence-dependent parameters
    [external_model = <string>]
        overrides default constants for the model, set in dna_model.h), by
        values specified by this option

-------------------------------------------------------------------------------

MC options:

    ensemble = nvt|npt
        ensemble of the simulation
    [check_energy_every = <float>]
        oxDNA will compute the energy from scratch, compare it with the
        current energy and throw an error if the difference is larger then
        check_energy_threshold. Defaults to 10.
    [check_energy_threshold = <float>]
        threshold for the energy check. Defaults to 1e-2f for single precision
        and 1e-6 for double precision.
    delta_translation = <float>
        controls the trial translational displacement, which is a randomly
        chosen number between -0.5*delta and 0.5*delta for each direction.
    delta_rotation = <float>
        controls the angular rotational displacement, given by a randomly
        chosen angle between -0.5*delta and 0.5*delta radians.
    delta_volume = <float>
        controls the volume change in npt simulations.
    P = <float>
        the pressure of the simulation. Used only if ensemble == npt.
    [adjust_moves = <bool>]
        if true, oxDNA will run for equilibration_steps time steps while
        changing the delta of the moves in order to have an optimal acceptance
        ratio. It does not make sense if equilibration_steps is 0 or not
        given. Defaults to false
    [maxclust = <int>]
        Default: N; maximum number of particles to be moved together. Defaults
        to the whole system
    [small_system = <bool>]
        Default: false; whether to use an interaction computation suited for
        small systems.
    [preserve_topology = <bool>]
        Default: false; sets a maximum size for the move attempt to 0.5, which
        guarantees that the topology of the system is conserved. Also prevents
        very large moves and might speed up simulations of larger systems,
        while suppressing diffusion
    [umbrella_sampling = <bool>]
        Default: false; whether to use umbrella sampling
    [op_file = <string>]
        Mandatory if umbrella_sampling is set to true; path to file with the
        description of the order parameter
    [weights_file = <string>]
        Mandatory if umbrella_sampling is set to true; path to file with the
        weights to use in umbrella sampling
    [last_hist_file = <string>]
        Optional if umbrella_sampling is set to true, otherwise ignored;
        Default: last_hist.dat; path to file where the histograms associated
        with umbrella sampling will be stored. This is printed with the same
        frequency as the energy file. Should become an observable sooner or
        later
    [traj_hist_file = <string>]
        Optional if umbrella_sampling is set to true, otherwise ignored;
        Default: traj_hist.dat; path to file where the series histograms
        associated with umbrella sampling will be stored, allowing to monitor
        the time evolution of the histogram and possibly to remove parts of
        the simulation. This is printed with the same frequency as the energy
        file. Should become an observable sooner or later
    [init_hist_file = <string>]
        Optional if umbrella_sampling is set to true, otherwise ignored;
        Default: none; path to a file to load a previous histogram from,
        useful if one wants to continue a simulation to obtain more
        statistics.
    [extrapolate_hist = <float>,<float>,..., <float>]
        Optional if umbrella_sampling is set to true, otherwise ignored;
        Default: none; series of temperatures to which to extrapolate the
        histograms. They can be given as float in reduced units, or the units
        can be specified as in the T option
    [safe_weights = <bool>]
        Default: true; whether to check consistency in between order parameter
        file and weight file. Only used if umbrella_sampling = true
    [default_weight = <float>]
        Default: none; mandatory if safe_weights = true; default weight for
        states that have no specified weight assigned from the weights file
    [skip_hist_zeros = <bool>]
        Default: false; Wether to skip zero entries in the traj_hist file
    [equilibration_steps = <int>]
        Default: 0; number of steps to ignore to allow for equilibration
    [type = rotation|traslation|possibly other as they get added]
        move to perform. No Defaults


-------------------------------------------------------------------------------

Forces/RepulsionPlane.h options:

    stiff = <float>
        stiffness of the repulsion.
    dir = <float>,<float>,<float>
        the vector normal to the plane: it should point towards the half-plane
        where the repulsion is not acting.
    position = <float>
        defines the position of the plane along the direction identified by
        the plane normal.
    particle = <int>
        index of the particle on which the force shall be applied. If -1, the
        force will be exerted on all the particles.

Forces/HarmonicTrap.h options:

    particle = <int>
 	the particle on which to exert the force
    pos0 = <float>,<float>,<float>
	rest position of the trap
    stiff = <float>
	stiffness of the trap (the force is stiff * dx)
    rate = <float>
	speed of the trap (length simulation units/time steps)
    dir = <float>,<float>,<float>
	direction of movement of the trap


OUTPUT FILE
-------------------------------------------------------------------------------

The energy.dat (default name, can be changed in the configuration file) has this layout for MC:
time potential_energy hydrogen_bonding_energy acc_trasl acc_rot [acc_volume]

The last_hist.dat has this layout for MC:
order_parameters biased_probabilities unbiased_probabilities

Mind that potential, kinetic and total energies are divided by the number of particles.

Configurations are saved in the trajectory file (appended one after the other).

-------------------------------------------------------------------------------

Multiple_seeds: 

The python launch_multi.py is used to generate multiple subfolders corresponding to each seed.
The seed number is incremented for each subfolder starting from an initial given value. 

python launch_multy.py dummy first_seed_number number_of_seeds

-------------------------------------------------------------------------------

Visualisation with Chimera:

oxDNA_svn/oxDNA/UTILS/traj2chimera.py last_conf.dat generated.top

-------------------------------------------------------------------------------

Making a simulation Movie for Windows:

Download VcXsrv instead of XMing 
Xlaunch and make sure native opengl is ticked, and open remote connection 
$HOME/oxDNA_svn/oxDNA/cogli1-code/build/bin/cogli1 -t generated.top trajectory.dat 
Save view u 
cogli1 -o -l view.cpy -t prova.top trajectory.dat 
Module load anaconda3/personal 
Source activate test_env 
for d in $(ls -v1 *.pov); do povray -D +A +H1200 +W1920 $d; done 
Source activate men_env 
ffmpeg -framerate 5 -pattern_type glob -i '*.png' -c:v ffv1 out.avi 
Save .avi in pc and load into VLC media player

-------------------------------------------------------------------------------
Other useful commands: 

Generate the configuration and topology files from a given sequence.txt: 
oxDNA_svn/oxDNA/UTILS/generate-sa.py <size_of_box> sequence.txt

Modify the generated.dat using unique topology: complementary bases allowed to bind will
be given numbers which add up to 3.





