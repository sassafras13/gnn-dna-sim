## calc MAE
import numpy as np
import torque_settings

fname_test = 'data_test.npz'
fname_pred = 'data_pred.npz'
cluster_size = torque_settings.cluster_size
beta_list = torque_settings.beta_list

data_test = np.load(fname_test)
data_pred = np.load(fname_pred)
data_R = data_test['R']
data_z = data_test['z']
data_F1 = data_test['F']
data_F2 = data_pred['F']

N_frame = data_R.shape[0]
N_site = data_R.shape[1]
N_cluster = N_site // cluster_size
mae_F_list = []
mae_M_list = []
mae_F0_list = []
mae_M0_list = []
data_F1_total = np.zeros((N_frame, N_cluster, 3))
data_F2_total = np.zeros((N_frame, N_cluster, 3))
data_M1_total = np.zeros((N_frame, N_cluster, 3))
data_M2_total = np.zeros((N_frame, N_cluster, 3))
for i in range(N_frame):
    # make prediction
    force_true = data_F1[i][0::cluster_size, :]
    data_F1_total[i] = force_true
    torque_true = data_F1[i][1::cluster_size, :]
    data_M1_total[i] = torque_true
    center = 0
    for n in range(cluster_size):
        xyz = data_R[i][n::cluster_size, :]
        center += beta_list[n] * xyz
    force_pred = 0
    torque_pred = 0
    for n in range(cluster_size):
        ff = data_F2[i][n::cluster_size, :]
        xyz = data_R[i][n::cluster_size, :] 
        rr = xyz - center
        mm = np.cross(rr, ff)
        force_pred += ff     
        torque_pred += mm
    data_F2_total[i] = force_pred
    data_M2_total[i] = torque_pred
    # calc mae
    mae_F_i = abs(force_pred - force_true)
    mae_F_list.append(mae_F_i)
    mae_F0_list.append(abs(force_true))
    mae_M_i = abs(torque_pred - torque_true)
    mae_M_list.append(mae_M_i) 
    mae_M0_list.append(abs(torque_true))

mae_F = np.mean(mae_F_list)
mae_M = np.mean(mae_M_list)
mae_F0 = np.mean(mae_F0_list)
mae_M0 = np.mean(mae_M0_list)
print('mae_F = %f  mae_F0 = %f' %(mae_F, mae_F0))
print('mae_M = %f  mae_M0 = %f' %(mae_M, mae_M0))


## plot
import matplotlib.pyplot as plt

site = N_cluster // 2
force_range = [-10, 10]
torque_range = [-5, 5]

fig11,ax11 = plt.subplots(1,1,figsize=(8,5))
dim = 0
ax11.plot(data_F1_total[:,site,dim], '.', label = 'true', color = 'red',  alpha = 1)
ax11.plot(data_F2_total[:,site,dim], 'o', label = 'pred', color = 'blue',  alpha = 0.5)
ax11.set_title('force') 
ax11.set_xlabel('t')
ax11.set_ylabel('Fx')
ax11.set_ylim(force_range)

fig12,ax12 = plt.subplots(1,1,figsize=(8,5))
dim = 1
ax12.plot(data_F1_total[:,site,dim], '.', label = 'true', color = 'red',  alpha = 1)
ax12.plot(data_F2_total[:,site,dim], 'o', label = 'pred', color = 'blue',  alpha = 0.5)
ax12.set_title('force') 
ax12.set_xlabel('t')
ax12.set_ylabel('Fy')
ax12.set_ylim(force_range)

fig13,ax13 = plt.subplots(1,1,figsize=(8,5))
dim = 2
ax13.plot(data_F1_total[:,site,dim], '.', label = 'true', color = 'red',  alpha = 1)
ax13.plot(data_F2_total[:,site,dim], 'o', label = 'pred', color = 'blue',  alpha = 0.5)
ax13.set_title('force') 
ax13.set_xlabel('t')
ax13.set_ylabel('Fz')
ax13.set_ylim(force_range)

fig21,ax21 = plt.subplots(1,1,figsize=(8,5))
dim = 0
ax21.plot(data_M1_total[:,site,dim], '.', label = 'true', color = 'red',  alpha = 1)
ax21.plot(data_M2_total[:,site,dim], 'o', label = 'pred', color = 'blue',  alpha = 0.5)
ax21.set_title('torque') 
ax21.set_xlabel('t')
ax21.set_ylabel('Mx')
ax21.set_ylim(torque_range)

fig22,ax22 = plt.subplots(1,1,figsize=(8,5))
dim = 1
ax22.plot(data_M1_total[:,site,dim], '.', label = 'true', color = 'red',  alpha = 1)
ax22.plot(data_M2_total[:,site,dim], 'o', label = 'pred', color = 'blue',  alpha = 0.5)
ax22.set_title('torque') 
ax22.set_xlabel('t')
ax22.set_ylabel('My')
ax22.set_ylim(torque_range)

fig23,ax23 = plt.subplots(1,1,figsize=(8,5))
dim = 2
ax23.plot(data_M1_total[:,site,dim], '.', label = 'true', color = 'red',  alpha = 1)
ax23.plot(data_M2_total[:,site,dim], 'o', label = 'pred', color = 'blue',  alpha = 0.5)
ax23.set_title('torque') 
ax23.set_xlabel('t')
ax23.set_ylabel('Mz')
ax23.set_ylim(torque_range)