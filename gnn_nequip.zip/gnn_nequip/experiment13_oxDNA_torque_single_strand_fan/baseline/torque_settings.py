import numpy as np

mode = 'force_torque'
cluster_size = 3

fan_R = 0.4 
fan_theta = np.pi/6
d = 0.8 + 2*fan_R * np.cos(fan_theta)
beta0 = 2*fan_R * np.cos(fan_theta) / d
beta1 = 0.4 / d
beta2 = 0.4 / d
beta_list = [beta0, beta1, beta2]

lambda_F = None
lambda_M = None