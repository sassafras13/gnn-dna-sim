## import
import numpy as np
import shutil
import os
 


## fan parameters
fan_R_list = [0.10, 0.20, 0.30, 0.35, 0.40, 0.45, 0.50]
fan_theta_deg_list = [15, 20, 25, 30]



## def run00_data
def run00_data(fan_R, fan_theta):
    ## file names
    fname1 = '../../oxDNA_datasets/dataset04_single_strand_DNA1/trajectory_new.dat'
    fname2 = '../../oxDNA_datasets/dataset04_single_strand_DNA1/system.top'
    fname3 = 'data_train.npz'
    fname4 = 'data_test.npz'
    N_train = 500
    N_test = 100
    seed = 10707

    ## import
    import numpy as np
    from oxdna_traj_parser_new import data_parser
    np.random.seed(seed)
      
    ## extract data
    print('parsing trajectory data...')
    parser = data_parser()
    parser.load_trajectory_data(fname1)
    parser.load_topology_data(fname2)
    data_R_atom = parser.data_R
    data_B_atom = parser.data_B
    data_N_atom = parser.data_N
    data_F_atom = parser.data_F
    data_M_atom = parser.data_M
    data_z_atom = parser.data_z

    ## torque parameters
    import torque_settings
    cluster_size = torque_settings.cluster_size
    fan_R = torque_settings.fan_R 
    fan_theta = torque_settings.fan_theta

    ## atom data to cluster data
    print('converting atom data to cluster data...')
    N_frame, N_atom, _ = data_R_atom.shape
    data_R = np.zeros((N_frame, cluster_size*N_atom, 3))
    data_F = np.zeros((N_frame, cluster_size*N_atom, 3))
    data_z = np.zeros(cluster_size*N_atom)
    data_E = np.zeros((N_frame, 1))
    for i in range(N_frame):
        print('    frame [%4d/%4d]' % (i+1,N_frame))
        for j in range(N_atom):
            k1 = 3*j + 0
            k2 = 3*j + 1
            k3 = 3*j + 2
            data_z[k1] = 2*(data_z_atom[j]-1) + 1
            data_z[k2] = 2*(data_z_atom[j]-1) + 2
            data_z[k3] = 2*(data_z_atom[j]-1) + 2
            r0 = data_R_atom[i, j]
            a1 = data_B_atom[i, j]
            a3 = data_N_atom[i, j]
            a2 = np.cross(a3, a1)
            ff = data_F_atom[i, j]
            mm = data_M_atom[i, j]
            r1 = r0 - 0.4*a1
            r2 = r0 + fan_R*np.cos(fan_theta)*a1 + fan_R*np.sin(fan_theta)*a2
            r3 = r0 + fan_R*np.cos(fan_theta)*a1 - fan_R*np.sin(fan_theta)*a2
            data_R[i, k1] = r1
            data_R[i, k2] = r2
            data_R[i, k3] = r3
            data_F[i, k1] = ff
            data_F[i, k2] = mm
            data_F[i, k3] = 0            

    ## convert length unit
    unit_length = 8.518  #Ang
    data_R = data_R * unit_length

    ## split train/test
    N_sample = N_train + N_test
    assert N_sample == data_E.shape[0]
    indices = np.random.permutation(N_sample)
    train_idx, test_idx = indices[:N_train], indices[N_train:]
    data1_E = data_E[train_idx, :]; data2_E = data_E[test_idx, :]
    data1_F = data_F[train_idx, :]; data2_F = data_F[test_idx, :]
    data1_R = data_R[train_idx, :]; data2_R = data_R[test_idx, :]

    ## output python data
    placeholder = np.array('', dtype='|S1')
    np.savez(fname3, E=data1_E, F=data1_F, R=data1_R, z=data_z, 
              name=placeholder, type=placeholder, theory=placeholder, md5=placeholder)
    np.savez(fname4, E=data2_E, F=data2_F, R=data2_R, z=data_z, 
              name=placeholder, type=placeholder, theory=placeholder, md5=placeholder)
    
    
    
## def run01_train
def run01_train():    
    ## train model
    from nequip_fun import nequip_fun
    import numpy as np
    fname = 'config.yaml'
    model = nequip_fun.train(fname)    
    
    # ## plot loss
    # import pandas as pd
    # loss_data = pd.read_csv('results/job/metrics_epoch.csv')
    # #list(loss_data.columns)
    # loss_train = loss_data[' training_loss']
    # loss_valid = loss_data[' validation_loss']
    # print('loss_train (total)  = %f' %(np.array(loss_train)[-1]))
    # print('loss_valid (total)  = %f' %(np.array(loss_valid)[-1]))
    
    # import matplotlib.pyplot as plt
    # fig1,ax1 = plt.subplots(1,1,figsize=(8,5))
    # ax1.plot(loss_train, label = 'training', color = 'r')
    # ax1.plot(loss_valid, label = 'validation', color = 'b')
    # ax1.legend(loc='best')
    # ax1.set_title('loss') 
    # ax1.set_xlabel('x')
    # ax1.set_ylabel('y')
    # ax1.grid(True)
    # fig1.savefig('loss.png')    
    
    ## deploy
    from nequip_fun import nequip_fun
    train_dir = 'results/job'
    out_file = 'model_deployed.pth'
    model = nequip_fun.deploy(train_dir, out_file)    
    
    
    
## run02_test
def run02_test():
    # parameters
    from nequip_fun import nequip_fun
    import numpy as np

    fname_model = 'model_deployed.pth'
    fname_config_test = 'config_test.yaml'
    fname_pred = 'data_pred.npz'
    batch_size = 50

    # run predict_batch
    energy_list, forces_list = nequip_fun.predict_batch(fname_model, fname_config_test, batch_size=batch_size)
    np.savez(fname_pred, E=energy_list, F=forces_list)

    
    
## loop: train_pred_mae
fan_R_list = np.array(fan_R_list)
fan_theta_list = np.array(fan_theta_deg_list) / 180 * np.pi
N_fan_R = len(fan_R_list)
N_fan_theta = len(fan_theta_list)
for i in range(N_fan_R):
    for j in range(N_fan_theta):
        # create job 
        fan_R = fan_R_list[i]
        fan_theta = fan_theta_list[j]
        fan_theta_deg = fan_theta_deg_list[j]
        job = 'job_R%4.2f_theta%2d'%(fan_R, fan_theta_deg)
        print('creating %s'%(job))        
        if os.path.isdir(job):
            shutil.rmtree(job)         
        shutil.copytree('template', job)
        os.chdir(job)    
        
        # set torque parameters
        d = 0.8 + 2*fan_R * np.cos(fan_theta)
        beta0 = 2*fan_R * np.cos(fan_theta) / d
        beta1 = 0.4 / d
        beta2 = 0.4 / d
        beta_list = [beta0, beta1, beta2]
        import torque_settings
        torque_settings.fan_R = fan_R 
        torque_settings.fan_theta = fan_theta
        torque_settings.beta_list = beta_list
        
        # run##
        run00_data(fan_R, fan_theta)
        run01_train()
        run02_test()
        
        # exit job folder        
        os.chdir('..')        
        print('\n'*3)
        
