## import
import numpy as np
import shutil
import os
 


## fan parameters
fan_R_list = [0.10, 0.20, 0.30, 0.35, 0.40, 0.45, 0.50]
fan_theta_deg_list = [15, 20, 25, 30]

   
    
## run02_test
def run02_test():
    # parameters
    from nequip_fun import nequip_fun
    import numpy as np

    fname_model = 'model_deployed.pth'
    fname_config_test = 'config_test.yaml'
    fname_pred = 'data_pred.npz'
    batch_size = 50

    # run predict_batch
    energy_list, forces_list = nequip_fun.predict_batch(fname_model, fname_config_test, batch_size=batch_size)
    np.savez(fname_pred, E=energy_list, F=forces_list)



## run03 mae
def run03_mae():
    ## calc MAE
    import numpy as np
    import torque_settings

    fname_test = 'data_test.npz'
    fname_pred = 'data_pred.npz'
    cluster_size = torque_settings.cluster_size
    beta_list = torque_settings.beta_list

    data_test = np.load(fname_test)
    data_pred = np.load(fname_pred)
    data_R = data_test['R']
    data_z = data_test['z']
    data_F1 = data_test['F']
    data_F2 = data_pred['F']

    N_frame = data_R.shape[0]
    N_site = data_R.shape[1]
    N_cluster = N_site // cluster_size
    mae_F_list = []
    mae_M_list = []
    mae_F0_list = []
    mae_M0_list = []
    data_F1_total = np.zeros((N_frame, N_cluster, 3))
    data_F2_total = np.zeros((N_frame, N_cluster, 3))
    data_M1_total = np.zeros((N_frame, N_cluster, 3))
    data_M2_total = np.zeros((N_frame, N_cluster, 3))
    for i in range(N_frame):
        # make prediction
        force_true = data_F1[i][0::cluster_size, :]
        data_F1_total[i] = force_true
        torque_true = data_F1[i][1::cluster_size, :]
        data_M1_total[i] = torque_true
        center = 0
        for n in range(cluster_size):
            xyz = data_R[i][n::cluster_size, :]
            center += beta_list[n] * xyz
        force_pred = 0
        torque_pred = 0
        for n in range(cluster_size):
            ff = data_F2[i][n::cluster_size, :]
            xyz = data_R[i][n::cluster_size, :] 
            rr = xyz - center
            mm = np.cross(rr, ff)
            force_pred += ff     
            torque_pred += mm
        data_F2_total[i] = force_pred
        data_M2_total[i] = torque_pred
        # calc mae
        mae_F_i = abs(force_pred - force_true)
        mae_F_list.append(mae_F_i)
        mae_F0_list.append(abs(force_true))
        mae_M_i = abs(torque_pred - torque_true)
        mae_M_list.append(mae_M_i) 
        mae_M0_list.append(abs(torque_true))

    mae_F = np.mean(mae_F_list)
    mae_M = np.mean(mae_M_list)
    mae_F0 = np.mean(mae_F0_list)
    mae_M0 = np.mean(mae_M0_list)
    print('mae_F = %f  mae_F0 = %f' %(mae_F, mae_F0))
    print('mae_M = %f  mae_M0 = %f' %(mae_M, mae_M0))
    return mae_F, mae_F0, mae_M, mae_M0
    
    
    
## loop: train_pred_mae
fan_R_list = np.array(fan_R_list)
fan_theta_list = np.array(fan_theta_deg_list) / 180 * np.pi
N_fan_R = len(fan_R_list)
N_fan_theta = len(fan_theta_list)
mae_F_table = np.zeros((N_fan_R, N_fan_theta))
mae_M_table = np.zeros((N_fan_R, N_fan_theta))
for i in range(N_fan_R):
    for j in range(N_fan_theta):
        # create job 
        fan_R = fan_R_list[i]
        fan_theta = fan_theta_list[j]
        fan_theta_deg = fan_theta_deg_list[j]
        job = 'job_R%4.2f_theta%2d'%(fan_R, fan_theta_deg)
        os.chdir(job)    
        
        # set torque parameters
        d = 0.8 + 2*fan_R * np.cos(fan_theta)
        beta0 = 2*fan_R * np.cos(fan_theta) / d
        beta1 = 0.4 / d
        beta2 = 0.4 / d
        beta_list = [beta0, beta1, beta2]
        import torque_settings
        torque_settings.fan_R = fan_R 
        torque_settings.fan_theta = fan_theta
        torque_settings.beta_list = beta_list
        
        # run##
        mae_F, mae_F0, mae_M, mae_M0 = run03_mae()
        mae_F_table[i, j] = mae_F
        mae_M_table[i, j] = mae_M
        
        # exit job folder        
        os.chdir('..')        
        print('\n'*3)
        


## summary
print('\n' * 10)
print('################################################### mae results ###################################################')
print('mae_F0 = %6.4f' % (mae_F0))
print('mae_M0 = %6.4f' % (mae_M0))
for i in range(N_fan_R):
    for j in range(N_fan_theta):
        fan_R = fan_R_list[i]
        fan_theta = fan_theta_list[j]
        fan_theta_deg = fan_theta_deg_list[j]
        mae_F = mae_F_table[i, j]
        mae_M = mae_M_table[i, j]
        print('fan_R = %4.2f  fan_theta_deg = %2d  mae_F = %6.4f  mae_M = %6.4f' %(fan_R, fan_theta_deg, mae_F, mae_M))
np.savez('mae_results.npz', mae_F0=mae_F0, mae_M0=mae_M0, mae_F_table=mae_F_table, mae_M_table=mae_M_table)