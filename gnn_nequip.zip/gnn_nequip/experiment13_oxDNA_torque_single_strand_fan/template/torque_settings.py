import numpy as np

mode = 'force_torque'
cluster_size = 3

fan_R = None
fan_theta = None
beta_list = None

lambda_F = None
lambda_M = None