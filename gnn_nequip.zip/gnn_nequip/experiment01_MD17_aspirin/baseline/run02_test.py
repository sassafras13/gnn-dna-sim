## make prediction
from nequip_fun import nequip_fun
import numpy as np

fname_model = 'model_deployed.pth'
fname_config_test = 'config_test.yaml'
fname_pred = 'aspirin_ccsd-pred.npz'
batch_size = 50

energy_list, forces_list = nequip_fun.predict_batch(fname_model, fname_config_test, batch_size=batch_size)

np.savez(fname_pred, E=energy_list, F=forces_list)
