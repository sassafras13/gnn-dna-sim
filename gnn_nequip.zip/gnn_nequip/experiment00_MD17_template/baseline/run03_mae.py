## calc MAE
import numpy as np
fname_test = 'data_test.npz'
fname_pred = 'data_pred.npz'

data_test = np.load(fname_test)
data_pred = np.load(fname_pred)
data_R = data_test['R']
data_z = data_test['z']
data_E1 = data_test['E']
data_F1 = data_test['F']
data_E2 = data_pred['E']
data_F2 = data_pred['F']

N_frame = data_R.shape[0]
N_atom = data_R.shape[1]
mae_E_list = []
mae_F_list = []

for i in range(N_frame):
    # make prediction
    energy_true = data_E1[i]
    force_true = data_F1[i]
    energy_pred = data_E2[i]
    force_pred = data_F2[i]
    # calc mae
    mae_E_i = abs(energy_pred - energy_true)
    mae_F_i = abs(force_pred - force_true)
    mae_E_list.append(mae_E_i)
    mae_F_list.append(mae_F_i)    
    
mae_E = np.mean(mae_E_list)
mae_F = np.mean(mae_F_list)
print('mae_E = %4.1f' %(mae_E))
print('mae_F = %4.1f' %(mae_F))


## read validation mae
import pandas as pd
loss_data = pd.read_csv('results/job/metrics_epoch.csv')
mae_E_valid = loss_data[' validation_e_mae']
mae_F_valid = loss_data[' validation_f_mae']
print('mae_E (validation) = %4.1f' % (mae_E_valid.values[-1]))
print('mae_F (validation) = %4.1f' % (mae_F_valid.values[-1]))