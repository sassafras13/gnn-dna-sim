import shutil
fname_test = 'data_test.npz'
fname_train = 'data_train.npz'

shutil.copyfile(fname_train, '../data/'+fname_train)
shutil.copyfile(fname_test, '../data/'+fname_test)