## calc MAE
import numpy as np
fname_test = '../data/data_test.npz'
fname_pred_template = 'job_Lmax_#_Ntrain_####/data_pred.npz'


def calc_MAE(job_name):    
    fname_pred = fname_pred_template.replace('job_Lmax_#_Ntrain_####', job_name)
    data_test = np.load(fname_test)
    data_pred = np.load(fname_pred)
    data_R = data_test['R']
    data_z = data_test['z']
    data_E1 = data_test['E']
    data_F1 = data_test['F']
    data_E2 = data_pred['E']
    data_F2 = data_pred['F']
    
    N_frame = data_R.shape[0]
    N_atom = data_R.shape[1]
    mae_E_list = []
    mae_F_list = []
    
    for i in range(N_frame):
        # make prediction
        energy_true = data_E1[i]
        force_true = data_F1[i]
        energy_pred = data_E2[i]
        force_pred = data_F2[i]
        # calc mae
        mae_E_i = abs(energy_pred - energy_true)
        mae_F_i = abs(force_pred - force_true)
        mae_E_list.append(mae_E_i)
        mae_F_list.append(mae_F_i)    
        
    mae_E = np.mean(mae_E_list)
    mae_F = np.mean(mae_F_list)
    return mae_E, mae_F
    # print('mae_E = %4.1f' %(mae_E))
    # print('mae_F = %4.1f' %(mae_F))


## calc
Lmax_list = [0, 1, 2, 3]
Ntrain_list = [150, 350, 550, 750, 950]
mae_F_list = np.zeros((len(Lmax_list), len(Ntrain_list)))
mae_E_list = np.zeros((len(Lmax_list), len(Ntrain_list)))
for i in range(len(Lmax_list)):
    for j in range(len(Ntrain_list)):
        Lmax = Lmax_list[i]
        Ntrain = Ntrain_list[j]
        job_name = 'job_Lmax_' + str(Lmax) + '_Ntrain_' + str(Ntrain).zfill(4) 
        mae_E, mae_F = calc_MAE(job_name)
        mae_F_list[i, j] = mae_F
        mae_E_list[i, j] = mae_E
        #print('mae_E = %4.1f' %(mae_E))
        #print('mae_F = %4.1f' %(mae_F))
        
        
## plot
import matplotlib
import matplotlib.pyplot as plt
fig1,ax1 = plt.subplots(1,1,figsize=(8,5))
for i in range(len(Lmax_list)):
    Lmax = Lmax_list[i]
    mae_F_data = mae_F_list[i, :]
    xx = Ntrain_list
    yy = mae_F_data
    log_xx = np.log(xx)
    log_yy = np.log(yy)
    A = np.vstack([log_xx, np.ones(len(log_xx))]).T
    b = log_yy[:, None]
    coeff = np.linalg.lstsq(A, b, rcond=None)[0]    
    log_xx0 = np.linspace(np.min(log_xx), np.max(log_xx), 101)
    log_yy0 = coeff[0] * log_xx0 + coeff[1]
    xx0 = np.exp(log_xx0)
    yy0 = np.exp(log_yy0)
    ax1.plot(xx, yy, '.', color='k')
    ax1.plot(xx0, yy0, '-', label='Lmax = %d  slope = %6.2f'%(Lmax, coeff[0]))
    ax1.set_xscale('log')
    ax1.set_yscale('log')
    ax1.legend(loc='best')
    ax1.set_title('Force MAE Analysis') 
    ax1.set_xlabel('Size of Training Data Set')
    ax1.set_ylabel('Force MAE')
    #ax1.grid(True)
    fig1.savefig('force_mae_analysis.png')
        
fig2,ax2 = plt.subplots(1,1,figsize=(8,5))
for i in range(len(Lmax_list)):
    Lmax = Lmax_list[i]
    mae_E_data = mae_E_list[i, :]    
    xx = Ntrain_list
    yy = mae_E_data
    log_xx = np.log(xx)
    log_yy = np.log(yy)
    A = np.vstack([log_xx, np.ones(len(log_xx))]).T
    b = log_yy[:, None]
    coeff = np.linalg.lstsq(A, b, rcond=None)[0]    
    log_xx0 = np.linspace(np.min(log_xx), np.max(log_xx), 101)
    log_yy0 = coeff[0] * log_xx0 + coeff[1]
    xx0 = np.exp(log_xx0)
    yy0 = np.exp(log_yy0)
    ax2.plot(xx, yy, '.', color='k')
    ax2.plot(xx0, yy0, '-', label='Lmax = %d  slope = %6.2f'%(Lmax, coeff[0]))
    ax2.set_xscale('log')
    ax2.set_yscale('log')
    ax2.legend(loc='best')
    ax2.set_title('Energy MAE Analysis') 
    ax2.set_xlabel('Size of Training Data Set')
    ax2.set_ylabel('Energy MAE')
    #ax2.grid(True)
    fig2.savefig('energy_mae_analysis.png')    
    
