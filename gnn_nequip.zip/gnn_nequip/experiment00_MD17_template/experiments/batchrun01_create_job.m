clc
clear

%% parameters
l_max_list = [0, 1, 2, 3];
n_train_list = [150, 350, 550, 750, 950];
n_val = 50;
learning_rate = 0.01;
batch_size = 10;
max_epochs = 200;
r_max = 4.0;


%% create jobs
for ii = 1:length(l_max_list)
    for jj = 1:length(n_train_list)
        l_max = l_max_list(ii);
        n_train = n_train_list(jj);
        job_name = sprintf('job_Lmax_%1d_Ntrain_%04d', l_max, n_train);
        fprintf('creating %s... \n', job_name)
        if isfolder(job_name)
            rmdir(job_name, 's')
        end
        mkdir(job_name)
        copyfile('../config_template/config.yaml', job_name);
        copyfile('../config_template/config_test.yaml', job_name); 
        fname = fullfile(job_name, 'config.yaml');
        replacement = {{'r_max:', sprintf('r_max: %f', r_max)}, ...
                       {'l_max:', sprintf('l_max: %d', l_max)}, ...
                       {'n_train:', sprintf('n_train: %d', n_train)}, ...
                       {'n_val:', sprintf('n_val: %d', n_val)}, ...
                       {'learning_rate:', sprintf('learning_rate: %f', learning_rate)}, ...
                       {'batch_size:', sprintf('batch_size: %d', batch_size)}, ...
                       {'max_epochs:', sprintf('max_epochs: %d', max_epochs)}, ...
                       };
        replaceText(fname, replacement)       
    end %ii
end %jj
fprintf('done! \n')