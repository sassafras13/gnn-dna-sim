## set wandb
import os
os.environ["WANDB_ANONYMOUS"] = "must"


## import
import numpy as np
import torch 
from ase.io import read, write
np.random.seed(0)
torch.manual_seed(0)


# ## rm results
# import shutil
# try:
#     shutil.rmtree('results')  
# except:
#     print('---')


## add path    
import sys
root_path = 'C:/UserData/user2022a/CMU/course_10707_ADL/project/nequip_new/nequip/' 
folder_list = ['.',
               'nequip', 
               'nequip/ase',
               'nequip/data',
               'nequip/model',
               'nequip/nn', 'nequip/nn/embedding', 
               'nequip/scripts', 
               'nequip/train',
               'nequip/utils', 'nequip/utils/torch_geometric']
for folder in folder_list:
    sys.path.append(root_path+folder)
    

## add path extension
root_path2 = 'C:/UserData/user2022a/CMU/course_10707_ADL/project/nequip_new/nequip_extension/' 
sys.path.append(root_path2)


## def: plot_loss
def plot_loss():
    import pandas as pd
    loss_data = pd.read_csv('results/job/metrics_epoch.csv')
    #list(loss_data.columns)
    loss_train = loss_data[' training_loss']
    loss_valid = loss_data[' validation_loss']
    import matplotlib
    import matplotlib.pyplot as plt
    fig1,ax1 = plt.subplots(1,1,figsize=(8,5))
    ax1.plot(loss_train, label = 'training', color = 'r')
    ax1.plot(loss_valid, label = 'validation', color = 'b')
    ax1.legend(loc='best')
    ax1.set_title('loss') 
    ax1.set_xlabel('x')
    ax1.set_ylabel('y')
    ax1.grid(True)
    fig1.savefig('loss.png')
    
    
## train and pred
from datetime import datetime
from nequip_fun import nequip_fun
import numpy as np
Lmax_list = [0, 1, 2, 3]
Ntrain_list = [150, 350, 550, 750, 950]
for Lmax in Lmax_list:
    for Ntrain in Ntrain_list:
        # cd job folder
        job_name = 'job_Lmax_' + str(Lmax) + '_Ntrain_' + str(Ntrain).zfill(4)        
        os.chdir(job_name)        
        print('#'*150)
        print('job = %s  time = %s' %(os.getcwd(), datetime.now().strftime("%H:%M:%S")))
        if os.path.isdir('results'):
            os.chdir('..')        
            print('\n'*6)
            continue
            
        # train
        fname_config = 'config.yaml'
        model = nequip_fun.train(fname_config)
        #plot_loss()
        
        # deploy
        train_dir = 'results/job'
        fname_model = 'model_deployed.pth'
        model_deployed = nequip_fun.deploy(train_dir, fname_model)
        
        # pred
        fname_config_test = 'config_test.yaml'
        fname_pred = 'data_pred.npz'
        pred_batch_size = 50
        energy_list, forces_list = nequip_fun.predict_batch(fname_model, fname_config_test, batch_size=pred_batch_size)
        np.savez(fname_pred, E=energy_list, F=forces_list)

        # exit job folder        
        os.chdir('..')        
        print('\n'*6)
        
        