function replaceText(fname, replacement)
%syntax:: replaceText('input.txt', {{'yu zhu', 'eric'}, {'sophie', 'yue liang'}}
fid = fopen(fname, 'r+');
text = {};
while ~feof(fid)
    line = fgetl(fid);
    for ii = 1:length(replacement)
        xx = replacement{ii};
        line = strrep(line, xx{1}, xx{2});
    end %ii
    text = [text, line];
end
fclose(fid);

fid = fopen(fname, 'w+');
for ii = 1:length(text)
    fprintf(fid, '%s\n', text{ii});
end %ii
fclose(fid);