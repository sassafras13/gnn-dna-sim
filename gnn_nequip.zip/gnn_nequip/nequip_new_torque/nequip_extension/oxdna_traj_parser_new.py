## import
import numpy as np


## data parser
class data_parser:
    def load_trajectory_data(self, fname_trajectory):
        with open(fname_trajectory, 'r') as f:
            # init
            lines = f.readlines()            
            N = len(lines) - 4            
            N_step = int((sum([(len(line.split()) == 6) for line in lines]) - 1) / 2)
            N_atom = N // N_step - 5
            
            # read data_E            
            data_E = np.zeros((N_step, 1)) 
            for i in range(N_step):
                line = lines[i*(N_atom+5) + N_atom + 3]
                E = float(line.split()[5])
                data_E[i, 0] = E
                
            # read data_*          
            data_R = np.zeros((N_step, N_atom, 3))
            data_B = np.zeros((N_step, N_atom, 3))
            data_N = np.zeros((N_step, N_atom, 3))
            data_F = np.zeros((N_step, N_atom, 3))
            data_M = np.zeros((N_step, N_atom, 3))
            for i in range(N_step):
                for j in range(N_atom):
                    line = lines[i*(N_atom+5) + j + 2]
                    data = [float(s) for s in line.split()]
                    data_R[i, j, :] = data[0:3]
                    data_B[i, j, :] = data[3:6]
                    data_N[i, j, :] = data[6:9]
                    data_F[i, j, :] = data[9:12]
                    data_M[i, j, :] = data[12:15]
                    
            # output     
            self.data_E = data_E
            self.data_R = data_R
            self.data_B = data_B
            self.data_N = data_N
            self.data_F = data_F
            self.data_M = data_M
   
       
    def load_topology_data(self, fname_topology):
        base_to_z = {'A':1, 'T':2, 'C':3, 'G':4}    #override 'H', 'He', 'Li', 'Be'
        with open(fname_topology, 'r') as f:
            lines = f.readlines()
            data_strand_index = []
            data_z = []
            data_site3_index = []
            data_site5_index = []
            for line in lines[1:]:
                info = line.split()
                strand_index = int(info[0])   
                z = int(base_to_z[info[1]])                
                site3_index = int(info[2])
                site5_index = int(info[3])
                data_strand_index.append(strand_index)
                data_z.append(z)
                data_site3_index.append(site3_index)
                data_site5_index.append(site5_index)
        self.data_strand_index = np.array(data_strand_index)  
        self.data_z = np.array(data_z)          
        self.data_site3_index = np.array(data_site3_index) 
        self.data_site5_index = np.array(data_site5_index)          
                
        
        
##########################################################################################################    
         
            
            #print('N_step = ', N_step, '  N_atom = ', N_atom)
            # calc N_atom
        #     for line in lines:
        #         if 't =' in line:
        #             t = self.parameters['dt'] * float(line.split()[2])
        #             data_t.append(t)                   
        #         elif 'b =' in line:
        #             pass
        #         elif 'E =' in line:
        #             E = float(line.split()[2])
        #             data_E.append(E)
        #         else:
        #             data = [float(s) for s in line.split()]
        #             x = data[0]; y = data[1]; z = data[2]
        #             Vx = data[9]; Vy = data[10]; Vz = data[11]
        #             data_R.append([x,y,z])
        #             data_V.append([Vx,Vy,Vz])
        # Nt = len(data_t) 
        # data_t = np.array(data_t)
        # data_E = np.array(data_E).reshape(Nt, 1)
        # data_R = np.array(data_R).reshape(Nt, -1, 3)
        # data_V = np.array(data_V).reshape(Nt, -1, 3)        
        # self.data_t = data_t
        # self.data_E = data_E
        # self.data_R = data_R
        # self.data_V = data_V
    # def __init__(self, fname_input, fname_trajectory, fname_topology):
    #     self.fname_input = fname_input
    #     self.fname_trajectory = fname_trajectory
    #     self.fname_topology = fname_topology
    #     self.parameters = {}
    #     self.parameters['mass'] = 315.75  #unit: AMU      
    
    # def load_input_parameter(self):
    #     with open(self.fname_input, 'r') as f:
    #         lines = f.readlines()
    #         for line in lines:
    #             # read temperature
    #             if 'T =' in line:
    #                 T = float(line.split()[2][:-1])
    #                 self.parameters['T'] = T
    #             # read time interval
    #             if 'dt =' in line:
    #                 dt = float(line.split()[2])
    #                 self.parameters['dt'] = dt
    #             # sanity check 
    #             if 'print_conf_interval =' in line:
    #                 d = int(float(line.split()[2]))
    #                 if d == 1:
    #                     raise NotImplementedError()
    #             if 'time_scale =' in line:
    #                 info = line.split()[2]
    #                 if info != 'linear':
    #                     raise NotImplementedError()       
    
    # def calculate_force(self):
    #     #finite differece: https://en.wikipedia.org/wiki/Finite_difference_coefficient
    #     data_V = self.data_V
    #     N = data_V.shape[0]
    #     dt = self.parameters['dt']
    #     mass = self.parameters['mass'] 
    #     data_dVdt = []
    #     for i in range(N):
    #         if i == 0:
    #             V0 = data_V[i]
    #             V1 = data_V[i+1]
    #             V2 = data_V[i+2]
    #             dVdt = +1/dt * (-3/2*V0 + 2*V1 - 1/2*V2)
    #         elif i == N-1:
    #             V0 = data_V[i]
    #             V1 = data_V[i-1]
    #             V2 = data_V[i-2]
    #             dVdt = -1/dt * (-3/2*V0 + 2*V1 - 1/2*V2)
    #         else:
    #             V1 = data_V[i-1]
    #             V2 = data_V[i+1]
    #             dVdt = 1/dt * (-1/2*V1 + 1/2*V2)
    #         data_dVdt.append(dVdt)
    #     data_F = mass * np.array(data_dVdt)
    #     self.data_F = data_F