## import
import numpy as np


## data parser
class data_parser:
    def __init__(self, fname_input, fname_trajectory, fname_topology):
        self.fname_input = fname_input
        self.fname_trajectory = fname_trajectory
        self.fname_topology = fname_topology
        self.parameters = {}
        self.parameters['mass'] = 315.75  #unit: AMU      
    
    def load_input_parameter(self):
        with open(self.fname_input, 'r') as f:
            lines = f.readlines()
            for line in lines:
                # read temperature
                if 'T =' in line:
                    T = float(line.split()[2][:-1])
                    self.parameters['T'] = T
                # read time interval
                if 'dt =' in line:
                    dt = float(line.split()[2])
                    self.parameters['dt'] = dt
                # # sanity check 
                # if 'print_conf_interval =' in line:
                #     d = int(float(line.split()[2]))
                #     if d == 1:
                #         raise NotImplementedError()
                # if 'time_scale =' in line:
                #     info = line.split()[2]
                #     if info != 'linear':
                #         raise NotImplementedError()                   
                    
    def load_trajectory_data(self):
        with open(self.fname_trajectory, 'r') as f:
            lines = f.readlines()
            data_t = []
            data_E = []  
            data_U = []
            data_R = []
            data_B = []
            data_N = []
            data_V = []
            data_W = []
            for line in lines:
                if 't =' in line:
                    t = self.parameters['dt'] * float(line.split()[2])
                    data_t.append(t)                   
                elif 'b =' in line:
                    pass
                elif 'E =' in line:
                    E = float(line.split()[2])
                    U = float(line.split()[3])
                    data_E.append(E)
                    data_U.append(U)
                else:
                    data = [float(s) for s in line.split()]
                    x = data[0]; y = data[1]; z = data[2]
                    Bx = data[3]; By = data[4]; Bz = data[5];
                    Nx = data[6]; Ny = data[7]; Nz = data[8];
                    Vx = data[9]; Vy = data[10]; Vz = data[11]
                    Wx = data[12]; Wy = data[13]; Wz = data[14]
                    data_R.append([x,y,z])
                    data_B.append([Bx,By,Bz])
                    data_N.append([Nx,Ny,Nz])
                    data_V.append([Vx,Vy,Vz])
                    data_W.append([Wx,Wy,Wz])
        Nt = len(data_t) 
        data_t = np.array(data_t)
        data_E = np.array(data_E).reshape(Nt, 1)
        data_U = np.array(data_U).reshape(Nt, 1)
        data_R = np.array(data_R).reshape(Nt, -1, 3)
        data_B = np.array(data_B).reshape(Nt, -1, 3)
        data_N = np.array(data_N).reshape(Nt, -1, 3)
        data_V = np.array(data_V).reshape(Nt, -1, 3)        
        data_W = np.array(data_W).reshape(Nt, -1, 3)        
        self.data_t = data_t
        self.data_E = data_E
        self.data_U = data_U
        self.data_R = data_R
        self.data_B = data_B
        self.data_N = data_N
        self.data_V = data_V
        self.data_W = data_W
       
    def load_topology_data(self):
        base_to_z = {'A':1, 'T':2, 'C':3, 'G':4}    #override 'H', 'He', 'Li', 'Be'
        with open(self.fname_topology, 'r') as f:
            lines = f.readlines()
            data_strand_index = []
            data_z = []
            data_site3_index = []
            data_site5_index = []
            for line in lines[1:]:
                info = line.split()
                strand_index = int(info[0])   
                z = int(base_to_z[info[1]])                
                site3_index = int(info[2])
                site5_index = int(info[3])
                data_strand_index.append(strand_index)
                data_z.append(z)
                data_site3_index.append(site3_index)
                data_site5_index.append(site5_index)
        self.data_strand_index = np.array(data_strand_index)  
        self.data_z = np.array(data_z)          
        self.data_site3_index = np.array(data_site3_index) 
        self.data_site5_index = np.array(data_site5_index)          
                
    
    def calculate_force(self):
        #finite differece: https://en.wikipedia.org/wiki/Finite_difference_coefficient
        data_V = self.data_V
        N = data_V.shape[0]
        dt = self.parameters['dt']
        mass = self.parameters['mass'] 
        data_dVdt = []
        for i in range(N):
            if i == 0:
                V0 = data_V[i]
                V1 = data_V[i+1]
                V2 = data_V[i+2]
                dVdt = +1/dt * (-3/2*V0 + 2*V1 - 1/2*V2)
            elif i == N-1:
                V0 = data_V[i]
                V1 = data_V[i-1]
                V2 = data_V[i-2]
                dVdt = -1/dt * (-3/2*V0 + 2*V1 - 1/2*V2)
            else:
                V1 = data_V[i-1]
                V2 = data_V[i+1]
                dVdt = 1/dt * (-1/2*V1 + 1/2*V2)
            data_dVdt.append(dVdt)
        data_F = mass * np.array(data_dVdt)
        self.data_F = data_F