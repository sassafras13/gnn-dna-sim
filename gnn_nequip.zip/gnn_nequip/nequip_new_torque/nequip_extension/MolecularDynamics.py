import numpy as np

class MolecularDynamics():
    def __init__(self):
        pass
    

    
    def verlet_brownian(self, atoms, dt, N_step, N_thermal=None, P_thermal=None, sigmal_thermal=None):
        #atoms: position, velocity, force, mass are set
        #dt: time interval
        #N_step: MD step number
        #P0: probability of thermalization
        #N0: thermalization interval
        #sigma: Maxwell distribution parameter
        masses = atoms.get_masses()[:,None]
        traj = [atoms]
        a = atoms.get_forces() / masses
        for i in range(N_step-1):
            # Newton dynamics (verlet)             
            x = atoms.get_positions()
            v = atoms.get_velocities()            
            x = x + v*dt + 1/2*a*dt**2
            atoms.set_positions(x)            
            a_old = a.copy()
            a = atoms.get_forces() / masses
            v = v + 1/2*(a_old + a)*dt            
            atoms.set_velocities(v)
            # thermalization
            if N_thermal != None:
                if (i+1) % N_thermal == 0:                    
                    v = atoms.get_velocities()                    
                    N_atom = len(atoms)
                    tf = np.random.binomial(1, P_thermal, size=N_atom)
                    v[tf==1] = sigmal_thermal * np.random.randn(sum(tf), 3)
                    atoms.set_velocities(v)
            traj.append(atoms.copy())
        return traj
    
    


            
    
######################################################################################################################
    # def nosehoover(self, atoms, dt, N_step, N_thermal=None, P_thermal=None, sigmal_thermal=None):
    #     traj = [atoms]
    #     for i in range(N_step-1):
    #         """Perform a MD step."""
    #         masses = atoms.get_masses()
    
    #         modified_acc = atoms.get_forces() / masses[:, np.newaxis]
    #         pos_fullstep = (
    #             atoms.get_positions()
    #             + dt * atoms.get_velocities()
    #             + 0.5 * dt*dt * modified_acc
    #         )
    #         vel_halfstep = atoms.get_velocities() + 0.5 * dt * modified_acc
    
    #         atoms.set_positions(pos_fullstep)        
    
            
    #         atoms.set_velocities(       vel_halfstep   + 0.5 * dt * (atoms.get_forces() / masses[:, np.newaxis])  )
    #         traj.append(atoms.copy())
    #     return traj
    
    
# def verlet_brownian(self, atoms, dt, N_step, N_thermal=None, P_thermal=None, sigmal_thermal=None):
#     #atoms: position, velocity, force, mass are set
#     #dt: time interval
#     #N_step: MD step number
#     #P0: probability of thermalization
#     #N0: thermalization interval
#     #sigma: Maxwell distribution parameter
#     masses = atoms.get_masses()[:,None]
#     traj = [atoms]
    
#     for i in range(N_step-1):
        
#         # Newton dynamics (verlet)             
#         a = atoms.get_forces() / masses
        
#         x = atoms.get_positions()
        
#         v = atoms.get_velocities()  
        
#         #dx = v*dt + 1/2*a*dt**2
#         x_new = x + v*dt + 1/2*a*dt**2
        
#         #v_half = v + 1/2*dt * a
        
#         atoms.set_positions(x_new)            
        
        
#         #a_old = a.copy()
#         a2 = atoms.get_forces() / masses
        
#         #dv = 1/2*(a + a2)*dt          
#         v_new = v + 1/2*(a + a2)*dt            
#         atoms.set_velocities(v_new)
#         # # thermalization
#         # if N_thermal != None:
#         #     if (i+1) % N_thermal == 0:                    
#         #         v = atoms.get_velocities()                    
#         #         N_atom = len(atoms)
#         #         tf = np.random.binomial(1, P_thermal, size=N_atom)
#         #         v[tf==1] = sigmal_thermal * np.random.randn(sum(tf), 3)
#         #         atoms.set_velocities(v)
#         traj.append(atoms.copy())
#     return traj    
            
    