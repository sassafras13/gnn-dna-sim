## import
import numpy as np
import torch
from ase import units


## fun
class nequip_fun():
    def __init__():
        pass
    
    # train
    def train(fname_config):
        # clear processed
        import os
        import shutil
        folder_parent = 'results'
        if os.path.isdir(folder_parent):            
            subfolder_list = [f.path for f in os.scandir(folder_parent) if f.is_dir()]
            for subfolder in subfolder_list:
                if 'processed' in subfolder:
                    shutil.rmtree(subfolder)
        # train
        from nequip_train import nequip_train
        model = nequip_train(fname_config)        
        return model
    
    # deploy
    def deploy(train_dir, out_file):
        from nequip_deploy import nequip_deploy
        model = nequip_deploy(train_dir, out_file)
        return model
    
    # predict
    def predict(fname_model, atoms, energy_units_to_eV=1, length_units_to_A=1):
        from nequip.ase import NequIPCalculator
        device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        calc = NequIPCalculator.from_deployed_model(model_path=fname_model, device=device, 
                                                    energy_units_to_eV=energy_units_to_eV,
                                                    length_units_to_A=length_units_to_A)
        atoms.set_calculator(calc=calc)        
        energy = atoms.get_total_energy()[0][0]
        forces = atoms.get_forces()
        return energy, forces
    
    # predict_batch
    def predict_batch(fname_model, fname_config_test, batch_size=50):        
        from nequip.data import AtomicData, Collater, dataset_from_config
        from nequip.utils import Config
        from nequip.scripts.deploy import load_deployed_model, R_MAX_KEY
        import torch
        import numpy as np
        from datetime import datetime
    
        device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        model, metadata = load_deployed_model(fname_model, device=device, set_global_options=True)
        model.eval()
        model_r_max = float(metadata[R_MAX_KEY])
        dataset_config = Config.from_file(fname_config_test, defaults={"r_max": model_r_max})
        dataset = dataset_from_config(dataset_config)
        c = Collater.for_dataset(dataset, exclude_keys=[])
    
        N = len(dataset)
        test_idcs = np.arange(N)
        batch_i = 0
        energy_pred_list = np.array([])
        forces_pred_list = np.array([])
        while True:
            this_batch_test_indexes = test_idcs[batch_i * batch_size : (batch_i + 1) * batch_size]
            data_batch = [dataset[int(idex)] for idex in this_batch_test_indexes]
            if len(data_batch) == 0:
                break
            batch = c.collate(data_batch)
            batch = batch.to(device)
            out = model(AtomicData.to_AtomicDataDict(batch))    
            energy_pred_batch = out['total_energy'].cpu().detach().numpy().squeeze(axis=1)
            forces_pred_batch = out['forces'].cpu().detach().numpy().reshape(len(data_batch), -1, 3)
            if len(energy_pred_list) == 0:
                energy_pred_list = energy_pred_batch
                forces_pred_list = forces_pred_batch
            else:                
                energy_pred_list = np.concatenate([energy_pred_list, energy_pred_batch], axis = 0)
                forces_pred_list = np.concatenate([forces_pred_list, forces_pred_batch], axis = 0) 
            batch_i += 1
            print('batch = %d  time = %s' % (batch_i, datetime.now().strftime("%H:%M:%S")))
        return energy_pred_list, forces_pred_list
        
    # md_oxdna
    def md_oxdna(fname_model, atoms, dt, N_step, N_thermal, temperature_K, mass=None, diff_coeff=2.5, energy_units_to_eV=1, length_units_to_A=1):
        #input:: fname_model: 'string'      deployed model file name
        #input:: atoms: Atoms               positions and velocities are initialized
        #input:: dt: [1]                    time interval
        #input:: N_step [1]                 time step number
        #input:: N_thermal [1]              thermalization step number, every N_thermal performs a thermalization
        #input:: temperature: [1]           temperature (unit = K)
        #input:: mass: [1]                  averaged neucleotide mass (unit = u)
        #input:: diff_coeff: [1]            diffusion coefficient
        #input:: energy_units_to_eV: [1]    energy = energy * energy_units_to_eV
        #input:: length_units_to_A: [1]     length = length * length_units_to_A
        #output:: traj = [atoms]            atomic configurations along the trajectory, len(traj) = N_step
        
        # set mass
        if mass != None:
            N_atom = len(atoms)
            atoms.set_masses(mass * np.ones(N_atom))
        
        # set force
        from nequip.ase import NequIPCalculator
        device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        calc = NequIPCalculator.from_deployed_model(model_path=fname_model, device=device, 
                                                    energy_units_to_eV=energy_units_to_eV,
                                                    length_units_to_A=length_units_to_A)
        atoms.set_calculator(calc=calc)         
        
        # calc P_thermal
        TT = temperature_K / 3000
        if N_thermal != None:
            P_thermal = (2 * TT * N_thermal * dt) / (TT * N_thermal * dt + 2 * diff_coeff)
        else:
            P_thermal = 0
        
        # calc sigmal_thermal
        m0 = atoms.get_masses().mean()
        sigma_thermal = np.sqrt(units.kB*temperature_K / m0)
        
        # call verlet_brownian
        from MolecularDynamics import MolecularDynamics
        traj = MolecularDynamics().verlet_brownian(atoms, dt, N_step, N_thermal, P_thermal, sigma_thermal)
        return traj
    
################################################################################################
