Irreps
======

.. _Irreps:

Syntax to specify irreps
------------------------

TODO: descripe irreps syntax here