NequIP User Guide
=================

 .. toctree::

    intro
    irreps
    conventions
    FAQ