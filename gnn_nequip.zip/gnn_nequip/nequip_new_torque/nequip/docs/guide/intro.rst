Tutorial: Introduction to NequIP
================================

TODO