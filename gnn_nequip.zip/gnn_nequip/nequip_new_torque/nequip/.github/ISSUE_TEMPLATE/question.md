---
name: Question
about: Ask a question about the codebase, documentation, or anything else.
title: "❓ [QUESTION]"
labels: question
assignees: ''

---

If this isn't an issue with the code or a request, please use our [GitHub Discussions](https://github.com/mir-group/nequip/discussions) instead.
