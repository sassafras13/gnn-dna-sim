import logging
from typing import Union, List

import torch.nn
from ._loss import find_loss_function
from ._key import ABBREV

from torch_runstats import RunningStats, Reduction

#eric <<<
def loss_force_torque(xyz_list, beta_list, force_pred_list, force_cluster_true_list, torque_cluster_true_list, cluster_size, lambda_F, lambda_M):
    # force loss (vectorized)
    force_cluster_pred_list = force_pred_list.reshape((-1,cluster_size,3)).sum(dim=1)
    delta_F = force_cluster_pred_list - force_cluster_true_list
    loss_F = torch.mean(delta_F**2)
        
    # torque loss
    loss_M = 0
    if cluster_size > 1:
        beta_list = beta_list.to(force_pred_list.device).float()
        xyz_list_ = xyz_list.reshape((-1, cluster_size, 3)).permute([0,2,1])
        r0_list_ = xyz_list_ @ beta_list
        r0_list = torch.repeat_interleave(r0_list_, cluster_size, dim=0)        
        dr_list = xyz_list - r0_list
        torque_pred_list = torch.linalg.cross(dr_list, force_pred_list)
        torque_cluster_pred_list = torque_pred_list.reshape((-1,cluster_size,3)).sum(dim=1)
        delta_M = torque_cluster_pred_list - torque_cluster_true_list
        loss_M = torch.mean(delta_M**2)
        
    # total loss
    loss = loss_F/lambda_F + loss_M/lambda_M
    return loss
#eric >>>



class Loss:
    """
    assemble loss function based on key(s) and coefficient(s)

    Args:
        coeffs (dict, str): keys with coefficient and loss function name

    Example input dictionaries

    ```python
    'total_energy'
    ['total_energy', 'forces']
    {'total_energy': 1.0}
    {'total_energy': (1.0)}
    {'total_energy': (1.0, 'MSELoss'), 'forces': (1.0, 'L1Loss', param_dict)}
    {'total_energy': (1.0, user_define_callables), 'force': (1.0, 'L1Loss', param_dict)}
    {'total_energy': (1.0, 'MSELoss'),
     'force': (1.0, 'Weighted_L1Loss', param_dict)}
    ```

    The loss function can be a loss class name that is exactly the same (case sensitive) to the ones defined in torch.nn.
    It can also be a user define class type that
        - takes "reduction=none" as init argument
        - uses prediction tensor and reference tensor for its call functions,
        - outputs a vector with the same shape as pred/ref

    """

    def __init__(
        self,
        coeffs: Union[dict, str, List[str]],
        coeff_schedule: str = "constant",
    ):

        self.coeff_schedule = coeff_schedule
        self.coeffs = {}
        self.funcs = {}
        self.keys = []

        mseloss = find_loss_function("MSELoss", {})
        if isinstance(coeffs, str):
            self.coeffs[coeffs] = 1.0
            self.funcs[coeffs] = mseloss
        elif isinstance(coeffs, list):
            for key in coeffs:
                self.coeffs[key] = 1.0
                self.funcs[key] = mseloss
        elif isinstance(coeffs, dict):
            for key, value in coeffs.items():
                logging.debug(f" parsing {key} {value}")
                coeff = 1.0
                func = "MSELoss"
                func_params = {}
                if isinstance(value, (float, int)):
                    coeff = value
                elif isinstance(value, str) or callable(value):
                    func = value
                elif isinstance(value, (list, tuple)):
                    # list of [func], [func, param], [coeff, func], [coeff, func, params]
                    if isinstance(value[0], (float, int)):
                        coeff = value[0]
                        if len(value) > 1:
                            func = value[1]
                        if len(value) > 2:
                            func_params = value[2]
                    else:
                        func = value[0]
                        if len(value) > 1:
                            func_params = value[1]
                else:
                    raise NotImplementedError(
                        f"expected float, list or tuple, but get {type(value)}"
                    )
                logging.debug(f" parsing {coeff} {func}")
                self.coeffs[key] = coeff
                self.funcs[key] = find_loss_function(
                    func,
                    func_params,
                )
        else:
            raise NotImplementedError(
                f"loss_coeffs can only be str, list and dict. got {type(coeffs)}"
            )

        for key, coeff in self.coeffs.items():
            self.coeffs[key] = torch.as_tensor(coeff, dtype=torch.get_default_dtype())
            self.keys += [key]

    #eric <<<
    # def __call__(self, pred: dict, ref: dict):

    #     loss = 0.0
    #     contrib = {}
    #     for key in self.coeffs:
    #         _loss = self.funcs[key](
    #             pred=pred,
    #             ref=ref,
    #             key=key,
    #             mean=True,
    #         )
    #         contrib[key] = _loss
    #         loss = loss + self.coeffs[key] * _loss

    #     return loss, contrib
    
    def __call__(self, pred: dict, ref: dict):
        import numpy as np
        import torque_settings
        mode = torque_settings.mode
        cluster_size = torque_settings.cluster_size
        beta_list = torque_settings.beta_list
        lambda_F = torque_settings.lambda_F
        lambda_M = torque_settings.lambda_M        
        
        if mode == 'force_torque':             
            xyz_list = ref['pos']
            force_pred_list = pred['forces']
            force_cluster_true_list = ref['forces'][0::cluster_size]
            if cluster_size > 1:
                torque_cluster_true_list = ref['forces'][1::cluster_size]
            else:
                torque_cluster_true_list = []
            loss = loss_force_torque(xyz_list, beta_list, force_pred_list, force_cluster_true_list, torque_cluster_true_list, cluster_size, lambda_F, lambda_M)           
            contrib = {}
        else: 
            loss = 0.0
            contrib = {}
            for key in self.coeffs:
                _loss = self.funcs[key](
                    pred=pred,
                    ref=ref,
                    key=key,
                    mean=True,
                )
                contrib[key] = _loss
                loss = loss + self.coeffs[key] * _loss

        return loss, contrib
    #eric >>>

class LossStat:
    """
    The class that accumulate the loss function values over all batches
    for each loss component.

    Args:

    keys (null): redundant argument

    """

    def __init__(self, loss_instance=None):
        self.loss_stat = {
            "total": RunningStats(
                dim=tuple(), reduction=Reduction.MEAN, ignore_nan=False
            )
        }
        self.ignore_nan = {}
        if loss_instance is not None:
            for key, func in loss_instance.funcs.items():
                self.ignore_nan[key] = (
                    func.ignore_nan if hasattr(func, "ignore_nan") else False
                )

    def __call__(self, loss, loss_contrib):
        """
        Args:

        loss (torch.Tensor): the value of the total loss function for the current batch
        loss (Dict(torch.Tensor)): the dictionary which contain the loss components
        """

        results = {}

        results["loss"] = self.loss_stat["total"].accumulate_batch(loss).item()

        # go through each component
        for k, v in loss_contrib.items():

            # initialize for the 1st batch
            if k not in self.loss_stat:
                self.loss_stat[k] = RunningStats(
                    dim=tuple(),
                    reduction=Reduction.MEAN,
                    ignore_nan=self.ignore_nan.get(k, False),
                )
                device = v.get_device()
                self.loss_stat[k].to(device="cpu" if device == -1 else device)

            results["loss_" + ABBREV.get(k, k)] = (
                self.loss_stat[k].accumulate_batch(v).item()
            )
        return results

    def reset(self):
        """
        Reset all the counters to zero
        """

        for v in self.loss_stat.values():
            v.reset()

    def to(self, device):
        for v in self.loss_stat.values():
            v.to(device=device)

    def current_result(self):
        results = {
            "loss_" + ABBREV.get(k, k): v.current_result().item()
            for k, v in self.loss_stat.items()
            if k != "total"
        }
        results["loss"] = self.loss_stat["total"].current_result().item()
        return results





































###############################################################################
    # # force loss
    # N_cluster = xyz_list.shape[0] // cluster_size
    # loss_F = 0
    # for i in range(N_cluster):
    #     F1 = torch.sum(force_pred_list[i*cluster_size:(i+1)*cluster_size, :], dim=0)
    #     F2 = force_cluster_true_list[i]
    #     loss_F = loss_F + torch.mean((F1 - F2)**2)
    # loss_F = loss_F / N_cluster / lambda_F