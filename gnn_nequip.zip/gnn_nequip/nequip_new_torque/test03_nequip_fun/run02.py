## deploy
from nequip_fun import nequip_fun
train_dir = 'results/aspirin/minimal'
out_file = 'model_deployed.pth'
model = nequip_fun.deploy(train_dir, out_file)
