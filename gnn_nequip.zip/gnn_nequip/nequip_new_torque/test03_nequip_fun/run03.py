## prepare atoms
import numpy as np
from ase import units
from ase import Atoms, Atom
fname = 'benchmark_data/aspirin_ccsd-train.npz'
data = np.load(fname)
data_R = data['R']
data_z = data['z']
xyz_list = data_R[0].squeeze()
Z_list = data_z
atom_list = []
for Z, xyz in zip(Z_list, xyz_list):
    atom_list.append(Atom(Z, xyz))
atoms = Atoms(atom_list)


## predict
from nequip_fun import nequip_fun
out_file = 'model_deployed.pth'
energy, forces = nequip_fun.predict(out_file, atoms)