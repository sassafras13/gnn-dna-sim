## initial atoms
import numpy as np
from ase import io
from ase import units
from ase import Atoms, Atom
fname = 'benchmark_data/aspirin_ccsd-train.npz'
data = np.load(fname)
data_R = data['R']
data_z = data['z']
xyz_list = data_R[0].squeeze()
Z_list = data_z
atom_list = []
for Z, xyz in zip(Z_list, xyz_list):
    atom_list.append(Atom(Z, xyz))
atoms_init = Atoms(atom_list)

## set intial velocity
from ase.md import velocitydistribution
velocitydistribution.MaxwellBoltzmannDistribution(atoms_init, temperature_K=300)
velocitydistribution.Stationary(atoms_init, preserve_temperature=False)      #P_com = 0
velocitydistribution.ZeroRotation(atoms_init, preserve_temperature=False)    #L_com = 0


# create md_log/xyz_strucs
import os
import shutil
md_log_dir = 'md_log/xyz_strucs'
if os.path.exists(md_log_dir):
    shutil.rmtree(md_log_dir)
os.makedirs(md_log_dir) 


# run md
from nequip_md import nequip_md
fname_model = 'model_deployed.pth'
T = 300.0
dt_fs = 0.1       #fs (NoseHoover: timestep=args.dt * units.fs)
N_step = 1000
save_frequency = 1
nequip_md(fname_model, atoms_init, T, dt_fs, N_step, save_frequency)


# read traj
def read_traj(fname_xyz, N_atom, N_step):
    traj_data = np.zeros((N_step, N_atom, 3))
    with open(fname_xyz, 'r') as f:
            lines = f.readlines()
            for i in range(N_step):
                for j in range(N_atom):
                    line = lines[i*(N_atom+2) + j + 2]
                    traj_data[i,j,:] = [float(line.split()[1]), float(line.split()[2]), float(line.split()[3])]
    return traj_data                   
         
fname_xyz = md_log_dir + '/nvt_.xyz'
N_atom = len(atoms_init)
traj_data = read_traj(fname_xyz, N_atom, N_step)
from scipy.io import savemat
savemat('traj2.mat', {'traj': traj_data})

