### calc MAE using predict (50 times slower than run06b!)
import numpy as np
from nequip_fun import nequip_fun
from ase import Atoms, Atom

fname_test = 'benchmark_data/aspirin_ccsd-test.npz'
fname_model = 'model_deployed.pth'

data_test = np.load(fname_test)
data_R = data_test['R']
data_z = data_test['z']
data_E = data_test['E']
data_F = data_test['F']

N_frame = data_F.shape[0]
N_atom = data_F.shape[1]
mae_E_list = []
mae_F_list = []

for i in range(N_frame):
    # create atoms
    xyz_list = data_R[i].squeeze()
    Z_list = data_z
    atom_list = []
    for Z, xyz in zip(Z_list, xyz_list):
        atom_list.append(Atom(Z, xyz))
    atoms = Atoms(atom_list)

    # make prediction
    energy_true = data_E[i]
    force_true = data_F[i]
    energy_pred, force_pred = nequip_fun.predict(fname_model, atoms)

    # calc mae
    mae_E_i = abs(energy_pred - energy_true)
    mae_F_i = abs(force_pred - force_true)
    mae_E_list.append(mae_E_i)
    mae_F_list.append(mae_F_i)
    print('i = ', i, 'mae_E = ', mae_E_i, ' mae_F = ', np.mean(mae_F_i))
    
    
mae_E = np.mean(mae_E_list)
mae_F = np.mean(mae_F_list)
print('\n'*10)
print('mae_E = %4.1f  mae_F = %4.1f ' %(mae_E, mae_F))


## read validation mae
import pandas as pd
loss_data = pd.read_csv('results/aspirin/minimal/metrics_epoch.csv')
mae_e_valid = loss_data[' validation_e_mae']
mae_f_valid = loss_data[' validation_f_mae']
print('mae_e_valid = ', mae_e_valid.values[-1])
print('mae_f_valid = ', mae_f_valid.values[-1])