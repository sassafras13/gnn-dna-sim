# train
from nequip_fun import nequip_fun
import numpy as np
fname = 'config.yaml'
model = nequip_fun.train(fname)


# plot loss
import pandas as pd
loss_data = pd.read_csv('results/aspirin/minimal/metrics_epoch.csv')
#list(loss_data.columns)
loss_train_f = loss_data[' training_loss_f']
#loss_train_e = loss_data[' training_loss_e']
loss_train = loss_data[' training_loss']
loss_valid_f = loss_data[' validation_loss_f']
#loss_valid_e = loss_data[' validation_loss_e']
loss_valid = loss_data[' validation_loss']
print('loss_train (forces) = %f' %(np.array(loss_train_f)[-1]))
#print('loss_train (energy) = %f' %(np.array(loss_train_e)[-1]))
print('loss_train (total)  = %f' %(np.array(loss_train)[-1]))
print('loss_valid (forces) = %f' %(np.array(loss_valid_f)[-1]))
#print('loss_valid (energy) = %f' %(np.array(loss_valid_e)[-1]))
print('loss_valid (total)  = %f' %(np.array(loss_valid)[-1]))


import matplotlib
import matplotlib.pyplot as plt
fig1,ax1 = plt.subplots(1,1,figsize=(8,5))
ax1.plot(loss_train, label = 'training', color = 'r')
ax1.plot(loss_valid, label = 'validation', color = 'b')
ax1.legend(loc='best')
ax1.set_title('loss') 
ax1.set_xlabel('x')
ax1.set_ylabel('y')
ax1.grid(True)
