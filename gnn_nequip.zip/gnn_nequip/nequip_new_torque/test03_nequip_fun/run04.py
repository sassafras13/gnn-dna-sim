from nequip_fun import nequip_fun
fname_model = 'model_deployed.pth'

## prepare atoms
import numpy as np
from ase import units
from ase import Atoms, Atom
fname = 'benchmark_data/aspirin_ccsd-train.npz'
data = np.load(fname)
data_R = data['R']
data_z = data['z']
xyz_list = data_R[0].squeeze()
Z_list = data_z
atom_list = []
for Z, xyz in zip(Z_list, xyz_list):
    atom_list.append(Atom(Z, xyz))
atoms = Atoms(atom_list)


## set intial velocity
from ase.md import velocitydistribution
velocitydistribution.MaxwellBoltzmannDistribution(atoms, temperature_K=300)
velocitydistribution.Stationary(atoms, preserve_temperature=False)      #P_com = 0
velocitydistribution.ZeroRotation(atoms, preserve_temperature=False)    #L_com = 0


## run MD
dt = 0.1 * units.fs
N_step = 1000
N_thermal = None #103
temperature_K = 300
traj = nequip_fun.md_oxdna(fname_model, atoms, dt, N_step, N_thermal, temperature_K)


## save traj
N_atom = len(atoms)
traj_data = np.zeros((N_step, N_atom, 3))
for i in range(N_step):
    traj_data[i, :, :] = traj[i].get_positions()
from scipy.io import savemat
savemat('traj.mat', {'traj': traj_data})