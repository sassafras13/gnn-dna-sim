clc
clear
close all

dt = 0.01;
x_range = [-20, 20];
y_range = [-20, 20];
z_range = [-20, 20];


load('traj_dbg.mat')  %traj

N_step = size(traj, 1);

figure

for ii = 1:N_step
    x = traj(ii, :, 1);
    y = traj(ii, :, 2);
    z = traj(ii, :, 3);
    scatter3(x,y,z, 'filled')
    view(40,35)
    xlim(x_range)
    ylim(y_range)
    zlim(z_range)
    title(sprintf('step = %d', ii))
    pause(dt)    
end %ii
