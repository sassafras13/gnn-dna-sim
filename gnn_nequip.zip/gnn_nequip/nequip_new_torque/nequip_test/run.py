import os
os.environ["WANDB_ANONYMOUS"] = "must"
# import
import numpy as np
import torch 
from ase.io import read, write
np.random.seed(0)
torch.manual_seed(0)

# rm results
import shutil
try:
    shutil.rmtree('results')  
except:
    print('---')

# add path    
import sys
root_path = 'C:/UserData/user2022a/CMU/course_10707_ADL/project/nequip/nequip_win_cpu/nequip/' 
folder_list = ['.',
               'nequip', 
               'nequip/ase',
               'nequip/data',
               'nequip/model',
               'nequip/nn', 'nequip/nn/embedding', 
               'nequip/scripts', 
               'nequip/train',
               'nequip/utils', 'nequip/utils/torch_geometric']
for folder in folder_list:
    sys.path.append(root_path+folder)


# train
from scripts.train import main as train_main
args = ['config.yaml']
train_main(args)  


#############################################################################################################
# fname = 'C:/UserData/user2022a/CMU/course_10707_ADL/project/nequip/nequip_cpu/test/results/aspirin/minimal/log'
# fid = open(fname)
# fid.close()
# shutil.rmtree('results', ignore_errors=True)
 
# # %%capture
# # # install wandb
# # !pip install wandb
# # # install nequip
# # !git clone --depth 1 "https://github.com/mir-group/nequip.git"
# # !pip install nequip/
# # # fix colab imports
# # import site
# # site.main()
# # # set to allow anonymous WandB
# import os
# os.environ["WANDB_ANONYMOUS"] = "must"

# import numpy as np
# import torch 
# from ase.io import read, write

# np.random.seed(0)
# torch.manual_seed(0)




# # #!rm -rf ./results
# # !rmdir /s /q benchmark_data
# # !rmdir /s /q results

# import shutil

# #dir_path = 'results'

# try:
#     shutil.rmtree('results')    
# except:
#     print('ok')
    
# import sys
# src_path = 'C:/UserData/user2022a/CMU/course_10707_ADL/project/nequip/nequip_cpu/nequip/nequip/scripts'
# sys.path.append(src_path)

# from train import *

# args = ['minimal.yaml']
# main(args)    



# # main('h')
# #!nequip-train minimal.yaml