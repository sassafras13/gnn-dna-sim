## initial atoms
import numpy as np
from ase import units
from ase import Atoms, Atom
fname = 'benchmark_data/aspirin_ccsd-train.npz'
data = np.load(fname)
data_R = data['R']
data_z = data['z']
xyz_list = data_R[0].squeeze()
Z_list = data_z
atom_list = []
for Z, xyz in zip(Z_list, xyz_list):
    atom_list.append(Atom(Z, xyz))
atoms_init = Atoms(atom_list)


# create md_log/xyz_strucs
import os
import shutil
md_log_dir = 'md_log/xyz_strucs'
if os.path.exists(md_log_dir):
    shutil.rmtree(md_log_dir)
os.makedirs(md_log_dir) 


# run md
from nequip_md import nequip_md
fname_model = 'model_deployed.pth'
T = 300.0
dt = 1.0
N_step = 1000
nequip_md(fname_model, atoms_init, T, dt, N_step)

