## deploy
from nequip_deploy import nequip_deploy
train_dir = 'results/aspirin/minimal'
out_file = 'model_deployed.pth'
nequip_deploy(train_dir, out_file)    