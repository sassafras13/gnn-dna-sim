## train
from nequip_train import nequip_train
fname = 'config.yaml'
nequip_train(fname)