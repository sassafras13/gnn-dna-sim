## file names
fname1 = '../oxDNA_datasets/dataset02_single_strand_DNA2/trajectory_new.dat'
fname2 = '../oxDNA_datasets/dataset02_single_strand_DNA2/system.top'
fname3 = 'data_train.npz'
fname4 = 'data_test.npz'
N_train = 500
N_test = 100
seed = 10707


## import
import numpy as np
from oxdna_traj_parser_new import data_parser
np.random.seed(seed)            

  
## extract data
print('parsing trajectory data...')
parser = data_parser()
parser.load_trajectory_data(fname1)
parser.load_topology_data(fname2)
data_R_atom = parser.data_R
data_B_atom = parser.data_B
data_N_atom = parser.data_N
data_F_atom = parser.data_F
data_M_atom = parser.data_M
data_z_atom = parser.data_z


## atom data to cluster data
print('converting atom data to cluster data...')
N_frame, N_atom, _ = data_R_atom.shape
data_R = np.zeros((N_frame, 3*N_atom, 3))
data_F = np.zeros((N_frame, 3*N_atom, 3))
data_z = np.zeros(3*N_atom)
data_E = np.zeros((N_frame, 1))
for i in range(N_frame):
    print('    frame [%4d/%4d]' % (i+1,N_frame))
    for j in range(N_atom):
        k1 = 3*j + 0
        k2 = 3*j + 1
        k3 = 3*j + 2
        data_z[k1] = 3*(data_z_atom[j]-1) + 1
        data_z[k2] = 3*(data_z_atom[j]-1) + 2
        data_z[k3] = 3*(data_z_atom[j]-1) + 3
        r0 = data_R_atom[i, j]
        a1 = data_B_atom[i, j]
        a3 = data_N_atom[i, j]
        a2 = np.cross(a3, a1)
        ff = data_F_atom[i, j]
        mm = data_M_atom[i, j]
        r1 = r0 + 0.4*a1
        r2 = r0 + 0.34*a1
        r3 = r0 - 0.34*a1 + 0.3408*a2
        data_R[i, k1] = r0
        data_R[i, k2] = r1
        data_R[i, k3] = r3
        data_F[i, k1] = ff
        data_F[i, k2] = mm
        data_F[i, k3] = 0
        

## convert length unit
unit_length = 8.518  #Ang
data_R = data_R * unit_length


## split train/test
N_sample = N_train + N_test
assert N_sample == data_E.shape[0]
indices = np.random.permutation(N_sample)
train_idx, test_idx = indices[:N_train], indices[N_train:]
data1_E = data_E[train_idx, :]; data2_E = data_E[test_idx, :]
data1_F = data_F[train_idx, :]; data2_F = data_F[test_idx, :]
data1_R = data_R[train_idx, :]; data2_R = data_R[test_idx, :]


## output python data
placeholder = np.array('', dtype='|S1')
np.savez(fname3, E=data1_E, F=data1_F, R=data1_R, z=data_z, 
          name=placeholder, type=placeholder, theory=placeholder, md5=placeholder)
np.savez(fname4, E=data2_E, F=data2_F, R=data2_R, z=data_z, 
          name=placeholder, type=placeholder, theory=placeholder, md5=placeholder)


############################################################################################
# ## convert units
# factor_energy = 1e3 * 41.42e-21 / 1.602e-19
# factor_length = 0.8518e-9 / 1e-10
# factor_force = factor_energy / factor_length
# data_E = data_E * factor_energy           # meV
# data_F = data_F * factor_force            # meV/Ang
# data_R = data_R * factor_length           # Ang


# fname1 = 'oxDNA_data/input_relax.txt'
# fname2 = 'oxDNA_data/trajectory_relax.dat'
# fname3 = 'oxDNA_data/system.top'
# fname4 = 'data.npz'


# parser = data_parser(fname1, fname2, fname3)
# parser.load_input_parameter()
# parser.load_trajectory_data()
# parser.load_topology_data()
# parser.calculate_force()
# data_E = parser.data_E
# data_F = parser.data_F
# data_R = parser.data_R
# data_z = parser.data_z
# data_strand_index = parser.data_strand_index
# data_site3_index = parser.data_site3_index
# data_site5_index = parser.data_site5_index


# ## topology
# topology = np.concatenate((data_strand_index[:,None], data_z[:,None], data_site3_index[:,None], data_site5_index[:,None]), axis=1)

# ## convert units
# factor_energy = 41.42e-21 / 1.602e-19
# factor_length = 0.8518e-9 / 1e-10
# factor_force = factor_energy / factor_length
# data_E = data_E * factor_energy           # eV
# data_F = data_F * factor_force            # eV/Ang
# data_R = data_R * factor_length           # Ang





# ## output matlab data
# from scipy.io import savemat
# savemat('data.mat', {'topology': topology, 'data_E': data_E, 'data_F': data_F, 'data_R': data_R, 'data_z': data_z})

