mode = 'force_torque'
cluster_size = 3
beta_list = [1.0, 0.0, 0.0]
lambda_F = None
lambda_M = None