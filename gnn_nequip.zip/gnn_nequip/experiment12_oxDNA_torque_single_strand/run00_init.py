## set wandb
import os
os.environ["WANDB_ANONYMOUS"] = "must"


## import
import numpy as np
import torch
np.random.seed(0)
torch.manual_seed(0)


## add path    
import sys
root_path = 'C:/UserData/user2022a/CMU/course_10707_ADL/project/nequip_new_torque/nequip/' 
folder_list = ['.',
               'nequip', 
               'nequip/ase',
               'nequip/data',
               'nequip/model',
               'nequip/nn', 'nequip/nn/embedding', 
               'nequip/scripts', 
               'nequip/train',
               'nequip/utils', 'nequip/utils/torch_geometric']
for folder in folder_list:
    sys.path.append(root_path+folder)
    

## add path extension
root_path2 = 'C:/UserData/user2022a/CMU/course_10707_ADL/project/nequip_new_torque/nequip_extension/' 
sys.path.append(root_path2)